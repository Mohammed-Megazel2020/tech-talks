<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use NeeonTheme;
use NeeonTheme_Helper;
use \RT_Postmeta;

if ( ! defined( 'ABSPATH' ) ) exit;

if ( !class_exists( 'RT_Postmeta' ) ) {
	return;
}

$Postmeta = RT_Postmeta::getInstance();

$prefix = NEEON_CORE_CPT_PREFIX;

/*-------------------------------------
#. Layout Settings
---------------------------------------*/
$nav_menus = wp_get_nav_menus( array( 'fields' => 'id=>name' ) );
$nav_menus = array( 'default' => __( 'Default', 'neeon-core' ) ) + $nav_menus;
$sidebars  = array( 'default' => __( 'Default', 'neeon-core' ) ) + NeeonTheme_Helper::custom_sidebar_fields();

$Postmeta->add_meta_box( "{$prefix}_page_settings", __( 'Layout Settings', 'neeon-core' ), array( 'page', 'post', 'neeon_team', 'neeon_service', 'neeon_case', 'neeon_testim' ), '', '', 'high', array(
	'fields' => array(
	
		"{$prefix}_layout_settings" => array(
			'label'   => __( 'Layouts', 'neeon-core' ),
			'type'    => 'group',
			'value'  => array(	
			
				"{$prefix}_layout" => array(
					'label'   => __( 'Layout', 'neeon-core' ),
					'type'    => 'select',
					'options' => array(
						'default'       => __( 'Default', 'neeon-core' ),
						'full-width'    => __( 'Full Width', 'neeon-core' ),
						'left-sidebar'  => __( 'Left Sidebar', 'neeon-core' ),
						'right-sidebar' => __( 'Right Sidebar', 'neeon-core' ),
					),
					'default'  => 'default',
				),		
				'neeon_sidebar' => array(
					'label'    => __( 'Custom Sidebar', 'neeon-core' ),
					'type'     => 'select',
					'options'  => $sidebars,
					'default'  => 'default',
				),
				"{$prefix}_page_menu" => array(
					'label'    => __( 'Main Menu', 'neeon-core' ),
					'type'     => 'select',
					'options'  => $nav_menus,
					'default'  => 'default',
				),
				"{$prefix}_top_bar" => array(
					'label' 	  => __( 'Top Bar', 'neeon-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'on'      => __( 'Enabled', 'neeon-core' ),
						'off'     => __( 'Disabled', 'neeon-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_top_bar_style" => array(
					'label' 	=> __( 'Top Bar Layout', 'neeon-core' ),
					'type'  	=> 'select',
					'options'	=> array(
						'default' => __( 'Default', 'neeon-core' ),
						'1'       => __( 'Layout 1', 'neeon-core' ),
						'2'       => __( 'Layout 2', 'neeon-core' ),
						'3'       => __( 'Layout 3', 'neeon-core' ),
						'4'       => __( 'Layout 4', 'neeon-core' ),
						'5'       => __( 'Layout 5', 'neeon-core' ),
						'6'       => __( 'Layout 6', 'neeon-core' ),
					),
					'default'   => 'default',
				),
				"{$prefix}_header_opt" => array(
					'label' 	  => __( 'Header On/Off', 'neeon-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'on'      => __( 'Enabled', 'neeon-core' ),
						'off'     => __( 'Disabled', 'neeon-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_header" => array(
					'label'   => __( 'Header Layout', 'neeon-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'1'       => __( 'Layout 1', 'neeon-core' ),
						'2'       => __( 'Layout 2', 'neeon-core' ),
						'3'       => __( 'Layout 3', 'neeon-core' ),
						'4'       => __( 'Layout 4', 'neeon-core' ),
						'5'       => __( 'Layout 5', 'neeon-core' ),
						'6'       => __( 'Layout 6', 'neeon-core' ),
						'7'       => __( 'Layout 7', 'neeon-core' ),
						'8'       => __( 'Layout 8', 'neeon-core' ),
						'9'       => __( 'Layout 9', 'neeon-core' ),
						'10'       => __( 'Layout 10', 'neeon-core' ),
						'11'       => __( 'Layout 11', 'neeon-core' ),
						'12'       => __( 'Layout 12', 'neeon-core' ),
						'13'       => __( 'Layout 13', 'neeon-core' ),
						'14'       => __( 'Layout 14', 'neeon-core' ),
						'15'       => __( 'Layout 15', 'neeon-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_footer" => array(
					'label'   => __( 'Footer Layout', 'neeon-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'1'       => __( 'Layout 1', 'neeon-core' ),
						'2'       => __( 'Layout 2', 'neeon-core' ),
						'3'       => __( 'Layout 3', 'neeon-core' ),
						'4'       => __( 'Layout 4', 'neeon-core' ),
						'5'       => __( 'Layout 5', 'neeon-core' ),
						'6'       => __( 'Layout 6', 'neeon-core' ),
						'7'       => __( 'Layout 7', 'neeon-core' ),
						'8'       => __( 'Layout 8', 'neeon-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_footer_area" => array(
					'label' 	  => __( 'Footer Area', 'neeon-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'on'      => __( 'Enabled', 'neeon-core' ),
						'off'     => __( 'Disabled', 'neeon-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_copyright_area" => array(
					'label' 	  => __( 'Copyright Area', 'neeon-core' ),
					'type'  	  => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'on'      => __( 'Enabled', 'neeon-core' ),
						'off'     => __( 'Disabled', 'neeon-core' ),
					),
					'default'  	  => 'default',
				),
				"{$prefix}_top_padding" => array(
					'label'   => __( 'Content Padding Top', 'neeon-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'0px'     => __( '0px', 'neeon-core' ),
						'10px'    => __( '10px', 'neeon-core' ),
						'20px'    => __( '20px', 'neeon-core' ),
						'30px'    => __( '30px', 'neeon-core' ),
						'40px'    => __( '40px', 'neeon-core' ),
						'50px'    => __( '50px', 'neeon-core' ),
						'60px'    => __( '60px', 'neeon-core' ),
						'70px'    => __( '70px', 'neeon-core' ),
						'80px'    => __( '80px', 'neeon-core' ),
						'90px'    => __( '90px', 'neeon-core' ),
						'100px'   => __( '100px', 'neeon-core' ),
						'110px'   => __( '110px', 'neeon-core' ),
						'120px'   => __( '120px', 'neeon-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_bottom_padding" => array(
					'label'   => __( 'Content Padding Bottom', 'neeon-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'0px'     => __( '0px', 'neeon-core' ),
						'10px'    => __( '10px', 'neeon-core' ),
						'20px'    => __( '20px', 'neeon-core' ),
						'30px'    => __( '30px', 'neeon-core' ),
						'40px'    => __( '40px', 'neeon-core' ),
						'50px'    => __( '50px', 'neeon-core' ),
						'60px'    => __( '60px', 'neeon-core' ),
						'70px'    => __( '70px', 'neeon-core' ),
						'80px'    => __( '80px', 'neeon-core' ),
						'90px'    => __( '90px', 'neeon-core' ),
						'100px'   => __( '100px', 'neeon-core' ),
						'110px'   => __( '110px', 'neeon-core' ),
						'120px'   => __( '120px', 'neeon-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_banner" => array(
					'label'   => __( 'Banner', 'neeon-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'on'	  => __( 'Enable', 'neeon-core' ),
						'off'	  => __( 'Disable', 'neeon-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_breadcrumb" => array(
					'label'   => __( 'Breadcrumb', 'neeon-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'on'      => __( 'Enable', 'neeon-core' ),
						'off'	  => __( 'Disable', 'neeon-core' ),
					),
					'default'  => 'default',
				),
				"{$prefix}_banner_type" => array(
					'label'   => __( 'Banner Background Type', 'neeon-core' ),
					'type'    => 'select',
					'options' => array(
						'default' => __( 'Default', 'neeon-core' ),
						'bgimg'   => __( 'Background Image', 'neeon-core' ),
						'bgcolor' => __( 'Background Color', 'neeon-core' ),
					),
					'default' => 'default',
				),
				"{$prefix}_banner_bgimg" => array(
					'label' => __( 'Banner Background Image', 'neeon-core' ),
					'type'  => 'image',
					'desc'  => __( 'If not selected, default will be used', 'neeon-core' ),
				),
				"{$prefix}_banner_bgcolor" => array(
					'label' => __( 'Banner Background Color', 'neeon-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, default will be used', 'neeon-core' ),
				),		
				"{$prefix}_page_bgimg" => array(
					'label' => __( 'Page/Post Background Image', 'neeon-core' ),
					'type'  => 'image',
					'desc'  => __( 'If not selected, default will be used', 'neeon-core' ),
				),
				"{$prefix}_page_bgcolor" => array(
					'label' => __( 'Page/Post Background Color', 'neeon-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, default will be used', 'neeon-core' ),
				),
			)
		)
	),
) );

/*-------------------------------------
#. Single Post Gallery
---------------------------------------*/
$Postmeta->add_meta_box( 'neeon_post_info', __( 'Post Info', 'neeon-core' ), array( 'post' ), '', '', 'high', array(
	'fields' => array(	
		"neeon_post_layout" => array(
			'label'   => __( 'Post Template', 'neeon-core' ),
			'type'    => 'select',
			'options' => array(
				'default'  => __( 'Default', 'neeon-core' ),
				'post-detail-style1'  => __( 'Layout 1', 'neeon-core' ),
				'post-detail-style2'  => __( 'Layout 2', 'neeon-core' ),
				'post-detail-style3'  => __( 'Layout 3', 'neeon-core' ),
			),
			'default'  => 'default',
		),
		"neeon_youtube_link" => array(
			'label'   => __( 'Youtube Link', 'neeon-core' ),
			'type'    => 'text',
			'default'  => '',
			'desc'  => __( 'Only work for the video post format', 'neeon-core' ),
		),
		"neeon_audio_track" => array(
			'label' => esc_html__( 'Music Tracks', 'neeon-core' ),
			'type'  => 'file',
			'desc'  => __( 'Only work for the audio post format', 'neeon-core' ),
		),
		'neeon_post_gallery' => array(
			'label' => __( 'Post Gallery', 'neeon-core' ),
			'type'  => 'gallery',
			'desc'  => __( 'Only work for the gallery post format', 'neeon-core' ),
		),
	),
) );

/*-------------------------------------
#. Team
---------------------------------------*/
$Postmeta->add_meta_box( 'neeon_team_settings', __( 'Team Member Settings', 'neeon-core' ), array( 'neeon_team' ), '', '', 'high', array(
	'fields' => array(
		'neeon_team_position' => array(
			'label' => __( 'Position', 'neeon-core' ),
			'type'  => 'text',
		),
		'neeon_team_website' => array(
			'label' => __( 'Website', 'neeon-core' ),
			'type'  => 'text',
		),
		'neeon_team_email' => array(
			'label' => __( 'Email', 'neeon-core' ),
			'type'  => 'text',
		),
		'neeon_team_phone' => array(
			'label' => __( 'Phone', 'neeon-core' ),
			'type'  => 'text',
		),
		'neeon_team_address' => array(
			'label' => __( 'Address', 'neeon-core' ),
			'type'  => 'text',
		),
		'neeon_team_socials_header' => array(
			'label' => __( 'Socials', 'neeon-core' ),
			'type'  => 'header',
			'desc'  => __( 'Enter your social links here', 'neeon-core' ),
		),
		'neeon_team_socials' => array(
			'type'  => 'group',
			'value'  => NeeonTheme_Helper::team_socials()
		),
	)
) );

$Postmeta->add_meta_box( 'neeon_team_skills', __( 'Team Member Skills', 'neeon-core' ), array( 'neeon_team' ), '', '', 'high', array(
	'fields' => array(
		'neeon_team_skill' => array(
			'type'  => 'repeater',
			'button' => __( 'Add New Skill', 'neeon-core' ),
			'value'  => array(
				'skill_name' => array(
					'label' => __( 'Skill Name', 'neeon-core' ),
					'type'  => 'text',
					'desc'  => __( 'eg. Marketing', 'neeon-core' ),
				),
				'skill_value' => array(
					'label' => __( 'Skill Percentage (%)', 'neeon-core' ),
					'type'  => 'text',
					'desc'  => __( 'eg. 75', 'neeon-core' ),
				),
				'skill_color' => array(
					'label' => __( 'Skill Color', 'neeon-core' ),
					'type'  => 'color_picker',
					'desc'  => __( 'If not selected, primary color will be used', 'neeon-core' ),
				),
			)
		),
	)
) );
$Postmeta->add_meta_box( 'neeon_team_contact', __( 'Team Member Contact', 'neeon-core' ), array( 'neeon_team' ), '', '', 'high', array(
	'fields' => array(
		'neeon_team_contact_form' => array(
			'label' => __( 'Contct Shortcode', 'neeon-core' ),
			'type'  => 'text',
		),
	)
) );