<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

add_action( 'widgets_init', 'neeon_widgets_init' );
function neeon_widgets_init() {
	// Register Custom Widgets
	register_widget( 'NeeonTheme_About_Widget' );
	register_widget( 'NeeonTheme_Address_Widget' );
	register_widget( 'NeeonTheme_Social_Widget' );
	register_widget( 'NeeonTheme_Post_Box' );
	register_widget( 'NeeonTheme_Post_Tab' );
	register_widget( 'NeeonTheme_Feature_Post' );
	register_widget( 'NeeonTheme_Product_Box' );
	register_widget( 'NeeonTheme_Category_Widget' );
	
}