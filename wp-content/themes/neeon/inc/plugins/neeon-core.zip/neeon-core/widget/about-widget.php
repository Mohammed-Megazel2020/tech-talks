<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

class NeeonTheme_About_Widget extends WP_Widget {
	public function __construct() {
		parent::__construct(
            'neeon_about_author', // Base ID
            esc_html__( 'Neeon : About Author', 'neeon-core' ), // Name
            array( 'description' => esc_html__( 'About Author Widget', 'neeon-core' ) ) // Args
            );
	}

	public function widget( $args, $instance ){
		echo wp_kses_post( $args['before_widget'] );
		if ( !empty( $instance['title'] ) ) {
			$html = apply_filters( 'widget_title', $instance['title'] );
			echo $html = $args['before_title'] . $html .$args['after_title'];
		}
		else {
			$html = '';
		}

		$img   = wp_get_attachment_image( $instance['ab_image'] );

		?>
		
		<div class="author-widget" style="background-image: url(<?php echo wp_get_attachment_image_url($instance['bg_image'],'full') ; ?>)">
			<?php	
			if( !empty( $instance['ab_image'] ) ){
				?><span><?php echo wp_kses( $img, 'alltext_allow' ); ?></span><?php
			}
			if( !empty( $instance['subtitle'] ) ){
				?><h3><?php echo esc_html( $instance['subtitle'] ); ?></a></h3><?php
			}
			if( !empty( $instance['text'] ) ){
				?><h4><?php echo esc_html( $instance['text'] ); ?></h4><?php
			}
			if( !empty( $instance['buttontext'] ) ){
				?><a class="about-btn button-style-2" href="<?php echo esc_url( $instance['buttonurl'] ); ?>"><?php echo esc_html( $instance['buttontext'] ); ?></a><?php
			}
			?>

		</div>

		<?php
		echo wp_kses_post( $args['after_widget'] );
	}

	public function update( $new_instance, $old_instance ){
		$instance              = array();
		$instance['title']     = ( ! empty( $new_instance['title'] ) ) ? sanitize_text_field( $new_instance['title'] ) : '';
		$instance['ab_image']  = ( ! empty( $new_instance['ab_image'] ) ) ? sanitize_text_field( $new_instance['ab_image'] ) : '';
		$instance['bg_image']  = ( ! empty( $new_instance['bg_image'] ) ) ? sanitize_text_field( $new_instance['bg_image'] ) : '';
		$instance['subtitle']  = ( ! empty( $new_instance['subtitle'] ) ) ? wp_kses_post( $new_instance['subtitle'] ) : '';
		$instance['text']      = ( ! empty( $new_instance['text'] ) ) ? wp_kses_post( $new_instance['text'] ) : '';
		$instance['buttontext']     = ( ! empty( $new_instance['buttontext'] ) ) ? sanitize_text_field( $new_instance['buttontext'] ) : '';
		$instance['buttonurl']     = ( ! empty( $new_instance['buttonurl'] ) ) ? sanitize_text_field( $new_instance['buttonurl'] ) : '';

		return $instance;
	}

	public function form( $instance ){
		$defaults = array(
			'title'   		=> esc_html__( 'About Author' , 'neeon-core' ),
			'subtitle'		=> '',
			'text'			=> '',
			'ab_image'    	=> '',
			'bg_image'    	=> '',
			'buttontext'   => '',
			'buttonurl'   	=> '',
			);
		$instance = wp_parse_args( (array) $instance, $defaults );

		$fields = array(
			'title'     => array(
				'label' => esc_html__( 'Title', 'neeon-core' ),
				'type'  => 'text',
			),
			'ab_image'    => array(
				'label'   => esc_html__( 'Author', 'blogxer-core' ),
				'type'    => 'image',
			),
			'bg_image'    => array(
				'label'   => esc_html__( 'background image', 'blogxer-core' ),
				'type'    => 'image',
			),
			'subtitle' => array(
				'label'   => esc_html__( 'Sub Title', 'neeon-core' ),
				'type'    => 'text',
			),
			'text' => array(
				'label'   => esc_html__( 'Text', 'neeon-core' ),
				'type'    => 'text',
			),
			'buttontext'     => array(
				'label' => esc_html__( 'Button Text', 'neeon-core' ),
				'type'  => 'text',
			),
			'buttonurl'     => array(
				'label' => esc_html__( 'Button URL', 'neeon-core' ),
				'type'  => 'text',
			), 
			
		);

		RT_Widget_Fields::display( $fields, $instance, $this );
	}
}