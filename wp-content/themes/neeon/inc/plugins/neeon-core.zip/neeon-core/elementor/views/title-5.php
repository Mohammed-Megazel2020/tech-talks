<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;
use Elementor\Utils;
extract($data);

?>
<div class="rt-section-title <?php echo esc_attr( $data['style'] ); ?>">
	<div class="title-holder <?php echo esc_attr( $data['line_position'] ); ?>">
		<?php if( !empty ( $data['title'] ) ) { ?>
		<<?php echo esc_attr( $data['heading_tag'] ); ?> class="entry-title <?php echo esc_attr( $data['animation'] );?> <?php echo esc_attr( $data['animation_effect'] );?>" data-wow-delay="1.2s" data-wow-duration="1s"><?php echo wp_kses_post( $data['title'] ); ?></<?php echo esc_attr( $data['heading_tag'] ); ?>>
		<?php } ?>
	</div>
</div>
