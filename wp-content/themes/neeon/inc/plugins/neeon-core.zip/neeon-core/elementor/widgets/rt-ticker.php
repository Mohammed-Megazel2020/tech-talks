<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Ticker extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT News Ticker', 'neeon-core' );
		$this->rt_base = 'rt-ticker';
		parent::__construct( $data, $args );
	}
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'neeon-core' ),
			),
			array(
				'type'    	  => Controls_Manager::TEXT,
				'id'      	  => 'ticker_title',
				'label'   	  => esc_html__( 'Ticker Title', 'neeon-core' ),
				'default' 	  => esc_html__( 'TRENDING', 'neeon-core' ),
			),
			array(
				'type'    	  => Controls_Manager::NUMBER,
				'id'      	  => 'ticker_item',
				'label'   	  => esc_html__( 'Number of Ticker', 'neeon-core' ),
				'default' 	  => 5,
			),
			array(
				'type'    	  => Controls_Manager::NUMBER,
				'id'      	  => 'ticker_delay',
				'label'   	  => esc_html__( 'Ticker Delay', 'neeon-core' ),
				'default' 	  => 3000,
			),
			array(
				'type'    	  => Controls_Manager::NUMBER,
				'id'      	  => 'ticker_speed',
				'label'   	  => esc_html__( 'Ticker Speed', 'neeon-core' ),
				'default' 	  => 0.10,
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'display_type',
				'label'   => esc_html__( 'Display Type', 'neeon-core' ),
				'options' => array(
					'fade' => esc_html__( 'Fade', 'neeon-core' ),
					'reveal' => esc_html__( 'Reveal', 'neeon-core' ),
				),
				'default' => 'fade',
			),
			array(
				'id'      => 'query_type',
				'label' => esc_html__( 'Query type', 'neeon-core' ),
            	'type' => Controls_Manager::SELECT,
            	'default' => 'category',
            	'options' => array(
					'category'  => esc_html__( 'Category', 'neeon-core' ),
                	'posts' => esc_html__( 'Posts', 'neeon-core' ),
				),
			),
			array(
				'id'                   => 'postid',
				'type'                 => 'rt-select2',
				'label'                => esc_html__('Selects posts', 'neeon-core'),
				'source_name'          => 'post_type',
				'source_type'          => 'post',
				'multiple'             => true,
				'label_block'          => true,
				'minimum_input_length' => 3,
				'maximum_selection_length' => -1,
				'condition' => array(
					'query_type' => 'posts',
				),
			),
			array(
				'id'      			   => 'catid',
				'type'                 => 'rt-select2',
				'label'                => esc_html__('Categories', 'neeon-core'),
				'source_name'          => 'taxonomy',
				'source_type'          => 'category',
				'multiple'             => true,
				'label_block'          => true,
				'minimum_input_length' => 1,
				'maximum_selection_length' => -1,
				'condition' => array(
					'query_type' => 'category',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'ticker_color',
				'label'   => esc_html__( 'Text Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-news-ticker .ticker-content a' => 'color: {{VALUE}}!important' ,
				),
				'separator' => 'before',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'ticker_hover_color',
				'label'   => esc_html__( 'Text Hover Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-news-ticker .ticker-content a:hover' => 'color: {{VALUE}}!important',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'ticker_bg_color',
				'label'   => esc_html__( 'Text Background Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-news-ticker .ticker-wrapper .ticker-swipe' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-news-ticker .ticker-wrapper .ticker-content' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-news-ticker .ticker-wrapper .ticker' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-news-ticker .ticker-wrapper .ticker-swipe span' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Background::get_type(),
				'name'    => 'heading_bg_color',
				'types'    => [ 'classic', 'gradient' ],
				'label'   => esc_html__( 'Heading Bg Shape', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-news-ticker .ticker-title',
			),
			
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		$template = 'rt-ticker';

		return $this->rt_template( $template, $data );
	}
}