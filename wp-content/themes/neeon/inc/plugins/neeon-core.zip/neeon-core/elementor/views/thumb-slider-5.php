<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use NeeonTheme;
use NeeonTheme_Helper;
use \WP_Query;

$neeon_has_entry_meta1  = ( $data['post_author'] == 'yes' || $data['post_date'] == 'yes' || $data['post_comment'] == 'yes' || $data['post_length'] == 'yes' && function_exists( 'neeon_reading_time' ) || $data['post_view'] == 'yes' && function_exists( 'neeon_views' ) ) ? true : false;

$neeon_has_entry_meta2  = ( $data['small_post_author'] == 'yes' || $data['small_post_date'] == 'yes' || $data['small_post_comment'] == 'yes' || $data['small_post_length'] == 'yes' && function_exists( 'neeon_reading_time' ) || $data['small_post_view'] == 'yes' && function_exists( 'neeon_views' ) ) ? true : false;

$thumb_size = 'neeon-size8';

$p_ids = array();
foreach ( $data['posts_not_in'] as $p_idsn ) {
    $p_ids[] = $p_idsn['post_not_in'];
}
$args = array(
    'posts_per_page'    => $data['itemlimit']['size'],
    'order'             => $data['post_ordering'],
    'orderby'           => $data['post_orderby'],
    'offset'            => $data['number_of_post_offset'],
    'ignore_sticky_posts' => $data['sticky_posts'],
    'post__not_in'      => $p_ids,
    'post_type'         => 'post',
    'post_status'       => 'publish',
);

if( $data['post_orderby'] == 'popular' ){
	$args['orderby'] = 'meta_value_num';
	$args['order'] = 'DESC';
	$args['meta_key'] = 'neeon_views';
}

if(!empty($data['catid'])){
	if( $data['query_type'] == 'category'){
	    $args['tax_query'] = [
	        [
	            'taxonomy' => 'category',
	            'field' => 'term_id',
	            'terms' => $data['catid'],                    
	        ],
	    ];

	}
}
if(!empty($data['postid'])){
	if( $data['query_type'] == 'posts'){
	    $args['post__in'] = $data['postid'];
	}
}

$query = new WP_Query( $args );
$temp = NeeonTheme_Helper::wp_set_temp_query( $query );

?>

<div class="rt-thumb-slider-default rt-thumb-slider-<?php echo esc_attr( $data['slider_style'] );?> neeon-horizontal-slider">
    <div class="swiper-container horizontal-slider" data-xld ="<?php echo esc_attr( $data['swiper_data'] );?>">
        <div class="swiper-wrapper">
        <?php
        if ( $query->have_posts() ) :?>
        <?php while ( $query->have_posts() ) : $query->the_post();?>
        <?php
        
            $title = wp_trim_words( get_the_title(), $data['title_count'], '' );
            $neeon_comments_number = number_format_i18n( get_comments_number() );
            $neeon_comments_html = $neeon_comments_number == 1 ? esc_html__( 'Comment' , 'neeon-core' ) : esc_html__( 'Comments' , 'neeon-core' );
            $neeon_comments_html = '<span class="comment-number">'. $neeon_comments_number . '</span> ' . $neeon_comments_html;
        
            $neeon_time_html = sprintf( '<span><span>%s </span>%s %s</span>', get_the_time( 'd' ), get_the_time( 'M' ), get_the_time( 'Y' ) );

            $id = get_the_ID();
            $youtube_link = get_post_meta( get_the_ID(), 'neeon_youtube_link', true );
            $audio_track = get_post_meta( get_the_ID(), 'neeon_audio_track' , true );

            ?>
            <div class="swiper-slide">
                <div class="rt-item rt-slide">
                    <div class="slide-animation" data-bg-image="<?php echo get_the_post_thumbnail_url(); ?>"></div>
                    <div class="container">
                      <div class="row <?php echo esc_attr( $data['content_align'] );?>">
                         <div class="<?php echo esc_attr( $data['slide_container'] );?>">
                            <div class="post-content">
                                <?php if ( ( $data['play_button_position'] == 'play-top' ) && ( $data['post_video'] == 'yes' ) && ( 'video' == get_post_format( $id ) && !empty( $youtube_link ) ) ) { ?>
                                    <div class="rt-video rt-video-top"><a class="rt-play <?php echo esc_attr( $data['play_button'] ); ?> rt-video-popup" href="<?php echo esc_url( $youtube_link );?>"><i class="fas fa-play"></i></a></div>
                                <?php } ?>
                                <?php if ( ( $data['post_audio'] == 'yes' && 'audio' == get_post_format( $id ) && !empty( $audio_track ) ) ) { ?>
                                    <div class="audio-player">
                                        <audio class="neeon-audio-plybtn" style="display: none">
                                            <source src="<?php echo wp_get_attachment_url( $audio_track ); ?>" type="audio/mp3">
                                        </audio>
                                    </div>
                                <?php } ?>
                               <?php if ( $data['post_category'] == 'yes' ) { ?>
                                    <?php if ( $data['cat_layout'] == 'cat_layout1' ) { ?>
                                        <div class="post-terms rt-cat"><?php echo the_category( ', ' );?></div>
                                    <?php } elseif ( $data['cat_layout'] == 'cat_layout2' ) { ?>
                                        <div class="post-terms"><?php echo neeon_category_prepare(); ?></div>
                                    <?php } elseif ( $data['cat_layout'] == 'cat_layout3' ) { ?>
                                        <div class="post-terms rt-cat rt-cat-3"><?php echo the_category( ', ' );?></div>
                                    <?php } ?>
                                <?php } ?>
                               <<?php echo esc_attr( $data['heading_tag'] ); ?> class="entry-title big-title title-animation-white-bold"><a href="<?php the_permalink();?>"><?php echo esc_html( $title );?></a></<?php echo esc_attr( $data['heading_tag'] ); ?>>
                               <?php if ( $neeon_has_entry_meta1 ) { ?>
                                <ul class="entry-meta">
                                    <?php if ( $data['post_author'] == 'yes' ) { ?>
                                    <li class="post-author"><?php esc_html_e( 'by ', 'neeon' );?><?php the_author_posts_link(); ?></li>
                                    <?php } if ( $data['post_date'] == 'yes' ) { ?> 
                                    <li class="post-date"><i class="far fa-calendar-alt"></i><?php echo get_the_date(); ?></li>             
                                    <?php } if ( $data['post_comment'] == 'yes' ) { ?>
                                    <li class="post-comment"><i class="far fa-comments"></i><a href="<?php echo get_comments_link( get_the_ID() ); ?>"><?php echo wp_kses( $neeon_comments_html , 'alltext_allow' );?></a></li>
                                    <?php } if ( ( $data['post_length'] == 'yes' ) && function_exists( 'neeon_reading_time' ) ) { ?>
                                    <li class="post-reading-time meta-item"><i class="far fa-clock"></i><?php echo neeon_reading_time(); ?></li>
                                    <?php } if ( ( $data['post_view'] == 'yes' ) && function_exists( 'neeon_views' ) ) { ?>
                                    <li><span class="post-views meta-item"><i class="fas fa-signal"></i><?php echo neeon_views(); ?></span></li>
                                    <?php } ?>
                                </ul>
                                <?php } ?>
                                <?php if ( ( $data['play_button_position'] == 'play-bottom' ) && ( $data['post_video'] == 'yes' ) && ( 'video' == get_post_format( $id ) && !empty( $youtube_link ) ) ) { ?>
                                    <div class="rt-video rt-video-bottom"><a class="rt-play <?php echo esc_attr( $data['play_button'] ); ?> rt-video-popup" href="<?php echo esc_url( $youtube_link );?>"><i class="fas fa-play"></i></a></div>
                                <?php } ?>
                            </div>
                         </div>
                      </div>
                   </div>
                </div>
            </div>
        <?php endwhile;?>        
        <?php endif;?>
         <!-- end swiper-slide -->
        <?php NeeonTheme_Helper::wp_reset_temp_query( $temp );?>
        </div>
    </div>
    <!-- end video-slider-style-1 -->

    <!-- start video-thumnail-area -->
    <div class="rt-thumnail-area <?php echo esc_attr( $data['box_layout'] );?>">
        <div class="container">
            <div class="swiper-container swiper-item-wrap horizontal-thumb-slider" data-xld ="<?php echo esc_attr( $data['swiper_data'] );?>">
                <div class="swiper-wrapper">
                    <?php
                    if ( $query->have_posts() ) :?>
                    <?php while ( $query->have_posts() ) : $query->the_post();
                        $small_title = wp_trim_words( get_the_title(), $data['small_title_count'], '' );
                    ?>                   
                    <div class="swiper-slide">
                        <div class="rt-item rt-slide-thumb"> 
                            <div class="rt-image">                           
                                <?php
                                    if ( has_post_thumbnail() ){
                                        the_post_thumbnail( $thumb_size );
                                    }
                                    else {
                                        if ( !empty( NeeonTheme::$options['no_preview_image']['id'] ) ) {
                                            echo wp_get_attachment_image( NeeonTheme::$options['no_preview_image']['id'], $thumb_size );
                                        }
                                        else {
                                            echo '<img class="wp-post-image" src="' . NeeonTheme_Helper::get_img( 'noimage_200X200.jpg' ) . '" alt="'.get_the_title().'">';
                                        }
                                    }
                                ?>
                            </div>
                            <div class="entry-content">
                                <?php if ( $data['small_post_category'] == 'yes' ) { ?>
                                    <?php if ( $data['cat_layout'] == 'cat_layout1' ) { ?>
                                        <div class="post-terms rt-cat"><?php echo the_category( ', ' );?></div>
                                    <?php } elseif ( $data['cat_layout'] == 'cat_layout2' ) { ?>
                                        <div class="post-terms"><?php echo neeon_category_prepare(); ?></div>
                                    <?php } elseif ( $data['cat_layout'] == 'cat_layout3' ) { ?>
                                        <div class="post-terms rt-cat rt-cat-3"><?php echo the_category( ', ' );?></div>
                                    <?php } ?>
                                <?php } ?>
                                <<?php echo esc_attr( $data['heading_tag_two'] ); ?> class="entry-title small-title title-animation-black-normal"><a href="javascript:void(0)"><?php echo esc_html( $small_title );?></a></<?php echo esc_attr( $data['heading_tag_two'] ); ?>>
                                <?php if ( $neeon_has_entry_meta2 ) { ?>
                                <ul class="entry-meta">
                                    <?php if ( $data['small_post_author'] == 'yes' ) { ?>
                                    <li class="post-author"><?php esc_html_e( 'by ', 'neeon' );?><?php the_author_posts_link(); ?></li>
                                    <?php } if ( $data['small_post_date'] == 'yes' ) { ?> 
                                    <li class="post-date"><i class="far fa-calendar-alt"></i><?php echo get_the_date(); ?></li>             
                                    <?php } if ( $data['small_post_comment'] == 'yes' ) { ?>
                                    <li class="post-comment"><i class="far fa-comments"></i><a href="<?php echo get_comments_link( get_the_ID() ); ?>"><?php echo wp_kses( $neeon_comments_html , 'alltext_allow' );?></a></li>
                                    <?php } if ( ( $data['small_post_length'] == 'yes' ) && function_exists( 'neeon_reading_time' ) ) { ?>
                                    <li class="post-reading-time meta-item"><i class="far fa-clock"></i><?php echo neeon_reading_time(); ?></li>
                                    <?php } if ( ( $data['small_post_view'] == 'yes' ) && function_exists( 'neeon_views' ) ) { ?>
                                    <li><span class="post-views meta-item"><i class="fas fa-signal"></i><?php echo neeon_views(); ?></span></li>
                                    <?php } ?>
                                </ul>
                                <?php } ?>
                            </div>
                            <?php if ( ( $data['small_post_video'] == 'yes' ) && ( 'video' == get_post_format( $id ) && !empty( $youtube_link ) ) ) { ?><div class="rt-video rt-small-video"><a class="play-btn-primary rt-video-popup" href="<?php echo esc_url( $youtube_link );?>"><i class="fas fa-play"></i></a></div>
                            <?php } ?>
                            <?php if ( ( $data['post_audio'] == 'yes' && 'audio' == get_post_format( $id ) && !empty( $audio_track ) ) ) { ?>
                                <div class="audio-player small-audio-player">
                                    <audio class="neeon-audio-plybtn" style="display: none">
                                        <source src="<?php echo wp_get_attachment_url( $audio_track ); ?>" type="audio/mp3">
                                    </audio>
                                </div>
                            <?php } ?>
                        </div>
                    </div>
                   <?php endwhile;?>        
                   <?php endif;?>
                </div>
                <div class="swiper-pagination"></div>
            </div>
        </div>
    </div>
</div>



