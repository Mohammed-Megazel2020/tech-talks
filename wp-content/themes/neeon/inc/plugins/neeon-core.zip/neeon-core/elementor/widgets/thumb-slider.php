<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Css_Filter;

if ( ! defined( 'ABSPATH' ) ) exit;

class Thumb_Slider extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Thumb Slider', 'neeon-core' );
		$this->rt_base = 'rt-thumb-slider';
		parent::__construct( $data, $args );
	}

	private function rt_load_scripts(){		
		//audio media
        wp_enqueue_style(  'wp-mediaelement');
        wp_enqueue_script( 'wp-mediaelement' );
	}

	public function rt_fields(){
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'post_not_in', array(
				'type'    => Controls_Manager::NUMBER,
				'label'   => __( 'Post ID', 'neeon-core' ),
				'default' => '0',
			)
		);
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'slider_style',
				'label'   => esc_html__( 'Slider Style', 'neeon-core' ),
				'default' => 'horizontal',
				'options' => array(
					'horizontal' => esc_html__( 'Horizontal 1', 'neeon-core' ),
					'horizontal-2' => esc_html__( 'Horizontal 2', 'neeon-core' ),
					'horizontal-3' => esc_html__( 'Horizontal 3', 'neeon-core' ),
					'horizontal-4' => esc_html__( 'Horizontal 4 podcast', 'neeon-core' ),
					'horizontal-5' => esc_html__( 'Horizontal 5', 'neeon-core' ),
					'vertical' => esc_html__( 'Vertical', 'neeon-core' ),
				),
			),	
			array(
				'type' => Controls_Manager::CHOOSE,
				'id'      => 'content_align',
				'mode'    => 'responsive',
				'label'   => esc_html__( 'Alignment', 'neeon-core' ),
				'options' => array(
					'justify-content-start text-start' => array(
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					),
					'justify-content-center text-center' => array(
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					),
					'justify-content-end text-end' => array(
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					),
				),
				'default' => '',
				'condition'   => array( 'slider_style!' => array( 'vertical' ) ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'cat_layout',
				'label'   => esc_html__( 'Category Layout', 'neeon-core' ),				
				'options' => array(
					'cat_layout1' 		=> esc_html__( 'Cat Layout 1', 'neeon-core' ),
					'cat_layout2' 		=> esc_html__( 'Cat Layout 2', 'neeon-core' ),
					'cat_layout3' 		=> esc_html__( 'Cat Layout 3', 'neeon-core' ),
				),
				'default' => 'cat_layout1',
			),					
	        array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'box_layout',
				'label'   => esc_html__( 'Box Layout', 'neeon-core' ),				
				'options' => array(
					'default-layout' => esc_html__( 'Default Layout', 'neeon-core' ),
					'box-layout' 	 => esc_html__( 'Box Layout', 'neeon-core' ),
				),
				'default' => 'default-layout',
				'condition'   => array( 'slider_style' => array( 'horizontal-4' ) ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'slide_container',
				'label'   => esc_html__( 'Slide Container', 'neeon-core' ),				
				'options' => array(
					'col-xl-6 col-lg-8' => esc_html__( 'col 6', 'neeon-core' ),
					'col-xl-7 col-lg-8' => esc_html__( 'col 7', 'neeon-core' ),
					'col-xl-8 col-lg-8' => esc_html__( 'col 8', 'neeon-core' ),
					'col-12' 			=> esc_html__( 'col full', 'neeon-core' ),
				),
				'default' => 'col-xl-6 col-lg-8',
				'condition'   => array( 'slider_style!' => array( 'vertical' ) ),
			),	
			/*end category*/			
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'itemlimit',
				'label'   => esc_html__( 'Item Limit', 'neeon-core' ),
				'range' => array(
	                'px' => array(
	                    'min' => 1,
	                    'max' => 12,
	               	),
		       	),
	            'default' => array(
	                'size' => 3,
	            ),
				'description' => esc_html__( 'Maximum number of Item', 'neeon-core' ),
			),			
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'title_count',
				'label'   => esc_html__( 'Title count', 'neeon-core' ),
				'default' => 15,
				'description' => esc_html__( 'Maximum number of title', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'small_title_count',
				'label'   => esc_html__( 'Small Title count', 'neeon-core' ),
				'default' => 5,
				'description' => esc_html__( 'Maximum number of title', 'neeon-core' ),
			),
			array(
				'mode' => 'section_end',
			),
			/*query option*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_query',
				'label'   => esc_html__( 'Query Settings', 'neeon-core' ),
			),
			/*Post Order*/
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'post_orderby',
				'label'   => esc_html__('Post Sorting', 'neeon-core'),
				'options' => array(
					'recent' 		=> esc_html__('Recent Post', 'neeon-core'),
					'popular' 		=> esc_html__('Popular Post', 'neeon-core'),
					'rand' 			=> esc_html__('Random Post', 'neeon-core'),
					'menu_order' 	=> esc_html__('Custom Order', 'neeon-core'),
					'title' 		=> esc_html__('By Name', 'neeon-core'),
				),
				'default' => 'recent',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'post_ordering',
				'label'   => esc_html__('Post Ordering', 'neeon-core'),
				'options' => array(
					'DESC'	=> esc_html__('Desecending', 'neeon-core'),
					'ASC'	=> esc_html__('Ascending', 'neeon-core'),
				),
				'default' => 'DESC',
				'condition' => [
					'post_orderby!' => ['popular'],
				],
			),
			/*Start category*/
			array(
				'id'      => 'query_type',
				'label' => esc_html__( 'Query type', 'neeon-core' ),
            	'type' => Controls_Manager::SELECT,
            	'default' => 'category',
            	'options' => array(
					'category'  => esc_html__( 'Category', 'neeon-core' ),
                	'posts' => esc_html__( 'Posts', 'neeon-core' ),
				),
			),
			array(
				'id'                   => 'postid',
				'type'                 => 'rt-select2',
				'label'                => esc_html__('Selects posts', 'neeon-core'),
				'source_name'          => 'post_type',
				'source_type'          => 'post',
				'multiple'             => true,
				'label_block'          => true,
				'minimum_input_length' => 3,
				'maximum_selection_length' => -1,
				'condition' => array(
					'query_type' => 'posts',
				),
			),
			array(
				'id'                   => 'catid',
				'type'                 => 'rt-select2',
				'label'                => esc_html__('Categories', 'neeon-core'),
				'source_name'          => 'taxonomy',
				'source_type'          => 'category',
				'multiple'             => true,
				'label_block'          => true,
				'minimum_input_length' => 1,
				'maximum_selection_length' => -1,
				'condition' => array(
					'query_type' => 'category',
				),
			),
			/*post offset*/
	        array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'number_of_post_offset',
				'label'   => __( 'Offset ( No of Posts )', 'neeon-core' ),
				'default' => '0',
				'separator' => 'before',
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'posts_not_in',
				'label'   => __( 'Exclude Post by ID', 'neeon-core' ),
				'fields' => $repeater->get_controls(),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'sticky_posts',
				'label'   => esc_html__( 'Sticky Posts', 'neeon-core' ),
				'options' => array(
					'1' => esc_html__( 'Off', 'neeon-core' ),
					'0' => esc_html__( 'On', 'neeon-core' ),
				),
				'default' => '1',
			),
			array(
				'mode' => 'section_end',
			),
			// Option
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_style',
				'label'   => esc_html__( 'Meta Option', 'neeon-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			// Tab For Normal view.
			array(
				'mode' => 'tabs_start',
				'id'   => 'meta_tabs_start',
			),			
			array(
				'mode'  => 'tab_start',
				'id'    => 'rt_tab_single_post',
				'label' => esc_html__( 'Single Post', 'neeon-core' ),
			),	
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_author',
				'label'       => esc_html__( 'Show Author', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_date',
				'label'       => esc_html__( 'Show Date', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_category',
				'label'       => esc_html__( 'Show Categories', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_comment',
				'label'       => esc_html__( 'Show Comment', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_length',
				'label'       => esc_html__( 'Show Lenght', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_view',
				'label'       => esc_html__( 'Show View', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_video',
				'label'       => esc_html__( 'Show Video', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
				'condition'   => array( 'slider_style' => array( 'horizontal', 'horizontal-2', 'horizontal-3', 'horizontal-4', 'horizontal-5' ) ),
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_read',
				'label'       => esc_html__( 'Show Read More', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
				'condition'   => array( 'slider_style' => array( 'vertical' ) ),
			),
			array(
				'mode' => 'tab_end',
			),
			// Tab For multi view.
			array(
				'mode'  => 'tab_start',
				'id'    => 'rt_tab_multi_post',
				'label' => esc_html__( 'Multi Post', 'neeon-core' ),
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_author',
				'label'       => esc_html__( 'Show Author', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_date',
				'label'       => esc_html__( 'Show Date', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_category',
				'label'       => esc_html__( 'Show Categories', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_comment',
				'label'       => esc_html__( 'Show Comment', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_length',
				'label'       => esc_html__( 'Show Lenght', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_view',
				'label'       => esc_html__( 'Show View', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_video',
				'label'       => esc_html__( 'Show Video', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
				'condition'   => array( 'slider_style' => array( 'horizontal-4' ) ),
			),
			array(
				'mode' => 'tab_end',
			),
			array(
				'mode' => 'tabs_end',
			),
			array(
				'type'    => Group_Control_Css_Filter::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'Slide Image Blend', 'neeon-core' ),	
				'name' => 'slide_blend', 
				'selector' => '{{WRAPPER}} .rt-thumb-slider-default .rt-item .slide-animation',
			),
			array(
				'type'    => Group_Control_Css_Filter::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'Thumb Image Blend', 'neeon-core' ),	
				'name' => 'blend', 
				'selector' => '{{WRAPPER}} .rt-thumb-slider-default .rt-item .rt-image img',
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'border_radius',
	            'label'   => __( 'Radius', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-thumb-slider-default .rt-slide-thumb .rt-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                
	                '{{WRAPPER}} .rt-thumb-slider-vertical .rt-slide-thumb .rt-image' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                 
	                '{{WRAPPER}} .rt-thumb-slider-horizontal-5 .rt-slide' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                  
	            ),
	            'separator' => 'before',
	        ),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'content_spacing',
	            'label'   => __( 'Content Spacing', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-thumb-slider-default .post-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
	            ),
	            'separator' => 'before',
	        ),
			array(
				'mode' => 'section_end',
			),
			// Title style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_title_style',
	            'label'   => esc_html__( 'Title Typo', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
	        array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Style', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-thumb-slider-default .rt-item .big-title',
			),
			array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'small_title_typo',
				'label'   => esc_html__( 'Small Title Style', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-thumb-slider-default .rt-item .small-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-thumb-slider-default .rt-item .entry-title a' => 'color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'title_margin',
	            'label'   => __( 'Margin', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-thumb-slider-default .rt-item .entry-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
	        array(
				'type' => Controls_Manager::SELECT,
				'id'      => 'heading_tag',
				'label'   => esc_html__( 'Big HTML Tag', 'neeon-core' ),
				'options' => array(
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				),
				'default' => 'h2',
			),
	        array(
				'type' => Controls_Manager::SELECT,
				'id'      => 'heading_tag_two',
				'label'   => esc_html__( 'Small HTML Tag', 'neeon-core' ),
				'options' => array(
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				),
				'default' => 'h3',
			),
			array(
				'mode' => 'section_end',
			),					
			// Meta style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_meta_style',
	            'label'   => esc_html__( 'Meta Style', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
	        array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'meta_typo',
				'label'   => esc_html__( 'Meta Typo', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-thumb-slider-default ul.entry-meta li',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'meta_color',
				'label'   => esc_html__( 'Meta Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-thumb-slider-default ul.entry-meta li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-thumb-slider-default ul.entry-meta li a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-thumb-slider-default .rt-item .rt-cat a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'meta_author_color',
				'label'   => esc_html__( 'Meta Author Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-thumb-slider-default .rt-item .post-author a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'meta_icon_color',
				'label'   => esc_html__( 'Meta Icon Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-thumb-slider-default ul.entry-meta li i' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'meta_small_color',
				'label'   => esc_html__( 'Small Meta Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-thumb-slider-horizontal-4 .rt-thumnail-area .rt-cat a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-thumb-slider-horizontal-4 .rt-thumnail-area ul.entry-meta li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-thumb-slider-horizontal-4 .rt-thumnail-area ul.entry-meta li a' => 'color: {{VALUE}}',
				),
				'condition'   => array( 'slider_style' => array( 'horizontal-4' ) ),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'meta_margin',
	            'label'   => __( 'Margin', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-thumb-slider-default ul.entry-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
	        array(
				'mode' => 'section_end',
			),
			// Play Button style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_playbutton_style',
	            'label'   => esc_html__( 'Play Button Style', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	            'condition'   => array( 'slider_style!' => array( 'vertical' ) ),
	        ),
	        array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'play_button',
				'label'   => esc_html__( 'Play Button', 'neeon-core' ),				
				'options' => array(
					'play-btn-primary' 			=> esc_html__( 'Play Style 1', 'neeon-core' ),
					'play-btn-white-lg' 		=> esc_html__( 'Play Style 2', 'neeon-core' ),
					'play-btn-white-xl' 		=> esc_html__( 'Play Style 3', 'neeon-core' ),
					'play-btn-transparent' 		=> esc_html__( 'Play Style 4', 'neeon-core' ),
					'play-btn-transparent-2' 	=> esc_html__( 'Play Style 5', 'neeon-core' ),
					'play-btn-transparent-3' 	=> esc_html__( 'Play Style 6', 'neeon-core' ),
				),
				'default' => 'play-btn-primary',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'play_button_position',
				'label'   => esc_html__( 'Play Button Position', 'neeon-core' ),				
				'options' => array(
					'play-bottom'  => esc_html__( 'Content Bottom', 'neeon-core' ),
					'play-top' 	=> esc_html__( 'Content Top', 'neeon-core' ),
				),
				'default' => 'play-bottom',
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'play_button_width',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Play Button Width', 'neeon-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-thumb-slider-default .rt-video .rt-play' => 'width: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'play_button_height',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Play Button Height', 'neeon-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-thumb-slider-default .rt-video .rt-play' => 'height: {{SIZE}}{{UNIT}};',
				),
			),			
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'play_button_radius',
	            'label'   => __( 'Radius', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-thumb-slider-default .rt-video .rt-play' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
	        array(
				'mode' => 'section_end',
			),
			// Audio Button
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_audio_button',
	            'label'   => esc_html__( 'Audio Button', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	            'condition'   => array( 'slider_style' => array( 'horizontal-4' ) ),
	        ),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_audio',
				'label'       => esc_html__( 'Show Audio', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'audio_button_color',
				'label'   => esc_html__( 'Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container .mejs-button' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'audio_button_hover_color',
				'label'   => esc_html__( 'Hover Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container .mejs-button:hover' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'audio_button_bg_color',
				'label'   => esc_html__( 'Background Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container .mejs-controls' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'audio_button_bg_hover_color',
				'label'   => esc_html__( 'Background Hover Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container .mejs-controls:hover' => 'background-color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'audio_button_radius',
	            'label'   => __( 'Button Radius', 'neeon-core' ),                 
	            'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
					'{{WRAPPER}} .audio-player .mejs-container .mejs-controls' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				),
	            'separator' => 'before',
	        ),
	        array(
				'mode' => 'section_end',
			),
			// Responsive Slider Columns
			array(
				'mode'        => 'section_start',
				'id'          => 'sec_slider_pervice',
				'label'       => esc_html__( 'PerView Options', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'mode' 			=> 'responsive',
				'id'      => 'thumb_slides_height',
				'label'   => esc_html__( 'Thumb Slides Height', 'neeon-core' ),
				'size_units' => array( 'px', '%' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 230,
						'max' => 1000,
					),
				),
				'default' => array(
					'unit' => 'px',
					'size' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-thumb-slider-vertical .rt-thumnail-area .swiper-item-wrap' => 'height: {{SIZE}}{{UNIT}};',
				),
				'condition'   => array( 'slider_style' => array( 'vertical' ) ),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'mode' 			=> 'responsive',
				'id'      => 'thumb_image_height',
				'label'   => esc_html__( 'Thumb Slides Height', 'neeon-core' ),
				'size_units' => array( 'px', '%' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 230,
						'max' => 1000,
					),
				),
				'default' => array(
					'unit' => 'px',
					'size' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-thumb-slider-horizontal-5 .rt-slide' => 'height: {{SIZE}}{{UNIT}};',
				),
				'condition'   => array( 'slider_style' => array( 'horizontal-5' ) ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'md_desktop',
				'label'   => esc_html__( 'Desktops: > 1200px', 'neeon-core' ),
				'default' => '3',
				'options' => array(
					'1' => esc_html__( '1', 'neeon-core' ),
					'2' => esc_html__( '2', 'neeon-core' ),
					'3' => esc_html__( '3',  'neeon-core' ),
					'4' => esc_html__( '4',  'neeon-core' ),
					'5' => esc_html__( '5',  'neeon-core' ),
					'6' => esc_html__( '6',  'neeon-core' ),
				),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'sm_desktop',
				'label'   => esc_html__( 'Desktops: > 992px', 'neeon-core' ),
				'default' => '2',
				'options' => array(
					'1' => esc_html__( '1', 'neeon-core' ),
					'2' => esc_html__( '2', 'neeon-core' ),
					'3' => esc_html__( '3',  'neeon-core' ),
					'4' => esc_html__( '4',  'neeon-core' ),
				),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'tablet',
				'label'   => esc_html__( 'Tablets: > 768px', 'neeon-core' ),
				'default' => '2',
				'options' => array(
					'1' => esc_html__( '1', 'neeon-core' ),
					'2' => esc_html__( '2', 'neeon-core' ),
					'3' => esc_html__( '3',  'neeon-core' ),
					'4' => esc_html__( '4',  'neeon-core' ),
				),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'mobile',
				'label'   => esc_html__( 'Phones: > 576px', 'neeon-core' ),
				'default' => '1',
				'options' => array(
					'1' => esc_html__( '1', 'neeon-core' ),
					'2' => esc_html__( '2', 'neeon-core' ),
					'3' => esc_html__( '3',  'neeon-core' ),
					'4' => esc_html__( '4',  'neeon-core' ),
				),
			),
			array(
				'mode' => 'section_end',
			),
			// Slider options
			array(
				'mode'        => 'section_start',
				'id'          => 'sec_slider',
				'label'       => esc_html__( 'Slider Options', 'neeon-core' ),
			),				
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'slider_autoplay',
				'label'       => esc_html__( 'Autoplay', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Enable or disable autoplay. Default: On', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'mode' 			=> 'responsive',
				'id'      => 'slides_space',
				'label'   => esc_html__( 'Slides Space', 'neeon-core' ),
				'size_units' => array( 'px', '%' ),
				'default' => array(
					'unit' => 'px',
					'size' => 24,
				),
				'description' => esc_html__( 'Slides Space. Default: 24', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'slider_autoplay_delay',
				'label'   => esc_html__( 'Autoplay Slide Delay', 'neeon-core' ),
				'default' => 5000,
				'description' => esc_html__( 'Set any value for example 5 seconds to play it in every 5 seconds. Default: 5 Seconds', 'neeon-core' ),
				'condition'   => array( 'slider_autoplay' => 'yes' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'slider_autoplay_speed',
				'label'   => esc_html__( 'Autoplay Slide Speed', 'neeon-core' ),
				'default' => 1000,
				'description' => esc_html__( 'Set any value for example .8 seconds to play it in every 2 seconds. Default: .8 Seconds', 'neeon-core' ),
				'condition'   => array( 'slider_autoplay' => 'yes' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'slider_loop',
				'label'       => esc_html__( 'Loop', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Loop to first item. Default: On', 'neeon-core' ),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();
		if($data['slider_autoplay']=='yes'){
			$data['slider_autoplay']=true;
		}
		else{
			$data['slider_autoplay']=false;
		}

		$swiper_data = array(
			'slidesPerView' 	=>2,
			'loop'				=>$data['slider_loop']=='yes' ? true:false,
			'spaceBetween'		=>$data['slides_space']['size'],
			'slideToClickedSlide' =>true,
			'autoplay'				=>array(
				'delay'  => $data['slider_autoplay_delay'],
			),
			'speed'      =>$data['slider_autoplay_speed'],
			'breakpoints' =>array(
				'0'    =>array('slidesPerView' =>1),
				'576'    =>array('slidesPerView' =>$data['mobile']),
				'768'    =>array('slidesPerView' =>$data['tablet']),
				'992'    =>array('slidesPerView' =>$data['sm_desktop']),
				'1200'    =>array('slidesPerView' =>$data['md_desktop']),				
			),
			'auto'   =>$data['slider_autoplay']
		);
		
		switch ( $data['slider_style'] ) {	
			case 'horizontal-5':
			$template = 'thumb-slider-6';
			break;
			case 'horizontal-4':
			$this->rt_load_scripts();
			$template = 'thumb-slider-5';
			break;		
			case 'horizontal-3':
			$template = 'thumb-slider-4';
			break;
			case 'horizontal-2':
			$template = 'thumb-slider-3';
			break;
			case 'vertical':
			$template = 'thumb-slider-2';
			break;
			default:
			$template = 'thumb-slider-1';
			break;
		}

		$data['swiper_data'] = json_encode( $swiper_data );   
		
		return $this->rt_template( $template, $data );
	}
}