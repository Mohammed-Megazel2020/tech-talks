<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */
namespace radiustheme\Neeon_Core;
use Elementor\Group_Control_Image_Size;
extract( $data );

$banners = array();
foreach ( $data['banner_lists'] as $banner_list ) {
    $banners[] = array(
        'slider_sub_title'  => $banner_list['slider_sub_title'],
        'slider_title'      => $banner_list['slider_title'],
        'slider_text'       => $banner_list['slider_text'],     
        'button_text'       => $banner_list['button_text'],
        'button_url'        => $banner_list['button_url']['url'],
        'img'      => $banner_list['banner_image']['url'] ? $banner_list['banner_image']['url'] : "", 
    );
}
?>

<div class="banner-slider">
    <div class="rt-swiper-slider swiper-slider" data-xld ="<?php echo esc_attr( $data['swiper_data'] );?>">
        <div class="swiper-wrapper <?php echo esc_attr( $data['animation'] );?>">
            <?php $i = 1;
                foreach ($banners as $banner){ ?>                   
                <div class="swiper-slide single-slide slide-<?php echo esc_attr( $i ); ?>">
                    <div class="single-slider" data-bg-image="<?php echo esc_attr($banner['img']); ?>">
                        <div class="container-fluid">
                            <div class="slider-content">
                                <div class="sub-title"><?php echo $banner['slider_sub_title']; ?></div>
                                <h2 class="slider-title <?php echo esc_attr( $data['title_align'] );?>"><?php echo $banner['slider_title']; ?></h2>
                                <div class="slider-text <?php echo esc_attr( $data['text_align'] );?>"><?php echo $banner['slider_text']; ?></div>
                                <?php if ( $data['button_display']  == 'yes' ) { ?>
                                <div class="slider-btn-area">
                                    <a class="button-style-2 btn-common rt-animation-out" href="<?php echo esc_url( $banner['button_url'] ); ?>"><?php echo wp_kses( $banner['button_text'], 'alltext_allow' ); ?><?php echo radius_arrow_shape(); ?></a>
                                </div>
                                <?php } ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php $i++; } ?>            
        </div>
        <?php if($data['display_arrow']=='yes'){  ?>
        <div class="swiper-navigation">
            <div class="swiper-button-next"></div>
            <div class="swiper-button-prev"></div>
        </div>
        <?php } if($data['display_buttet']=='yes') { ?>
        <div class="swiper-pagination"></div>
        <?php } ?>
    </div>    
</div>

<?php


