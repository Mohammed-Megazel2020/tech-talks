<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use NeeonTheme;
use NeeonTheme_Helper;
use \WP_Query;

$p_ids = array();
foreach ( $data['posts_not_in'] as $p_idsn ) {
	$p_ids[] = $p_idsn['post_not_in'];
}
$args = array(
	'posts_per_page' 	=> $data['itemlimit']['size'],
	'order' 			=> $data['post_ordering'],
	'orderby' 			=> $data['post_orderby'],
	'offset' 	 	 	=> $data['number_of_post_offset'],
	'ignore_sticky_posts' => $data['sticky_posts'],
	'post__not_in'   	=> $p_ids,
	'post_type'			=> 'post',
	'post_status'		=> 'publish',
);

if( $data['post_orderby'] == 'popular' ){
	$args['orderby'] = 'meta_value_num';
	$args['order'] = 'DESC';
	$args['meta_key'] = 'neeon_views';
}

if(!empty($data['catid'])){
	if( $data['query_type'] == 'category'){
	    $args['tax_query'] = [
	        [
	            'taxonomy' => 'category',
	            'field' => 'term_id',
	            'terms' => $data['catid'],                    
	        ],
	    ];

	}
}
if(!empty($data['postid'])){
	if( $data['query_type'] == 'posts'){
	    $args['post__in'] = $data['postid'];
	}
}

$query = new WP_Query( $args );
$temp = NeeonTheme_Helper::wp_set_temp_query( $query );

?>
<div class="rt-post-tab-default rt-post-tab-<?php echo esc_attr( $data['style'] );?> <?php echo esc_attr( $data['box_layout'] );?> <?php echo esc_attr( $data['play_button_position'] );?> <?php if ( $data['all_button'] == 'hide' ) {?>hide-all<?php } ?> rt-isotope-wrapper">
	<div class="section-title rt_ajax_tab_section">
		<<?php echo esc_attr( $data['section_heading_tag'] ); ?> class="related-title"><?php echo wp_kses_post( $data['section_title_text'] ); ?>
			<span class="titledot"></span>
			<span class="titleline"></span>
		</<?php echo esc_attr( $data['section_heading_tag'] ); ?>>		
		<div class="rt-post-tab">
			<div class="post-cat-tab rt_ajax_tab" data-layout="4" data-args="<?php echo htmlspecialchars(json_encode($data), ENT_QUOTES, 'UTF-8'); ?>">
				<?php 
				$all_btn = ( $data['all_button'] == 'show' );
				if ( $all_btn ) { ?>
					<a href="#" data-id="*" class="current"><?php esc_html_e( 'All', 'neeon-core' );?></a>
				<?php } ?>
				<?php
				$terms = get_terms( array( 
				    'taxonomy' => 'category', 
				    'include'  => $data['catid'],
				    'orderby' => 'include',
				) );				
				foreach( $terms as $key => $term ) {
					?>
					<a href="#" class="<?php if ( !$all_btn && $key == 0) echo esc_attr('current'); ?>" data-id="<?php echo esc_attr($term->term_id); ?>"><?php echo esc_html($term->name); ?></a>
					<?php
				}
				?> 
			</div>
		</div>
  	</div>
	<div class="row rt-ajax-tab-content <?php echo esc_attr( $data['item_space'] );?>">	
		<?php 
			$ajax_tab = new AjaxTab();
			$ajax_tab->rt_ajax_tab_four(null, $data);
			NeeonTheme_Helper::wp_reset_temp_query( $temp ); 
		?>
	</div>
</div>