<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;
use NeeonTheme_Helper;
use WP_Query;

if( is_rtl() ) {
    $rtl = 'rtl';
}else {
    $rtl = 'ltr';
}
$ticker_data = array(
    'speed'             =>$data['ticker_speed'],
    'titleText'         =>$data['ticker_title'],
    'displayType'       =>$data['display_type'],
    'pauseOnItems'      =>$data['ticker_delay'],
    'direction'         => $rtl,
);
$ticker_data = json_encode( $ticker_data );

?>

<div class="rt-news-ticker" data-xld ='<?php echo esc_attr( $ticker_data );?>'>
    <ol id="rt-news-ticker" class="js-hidden">
    <?php
        $no_duplicate_post = array();
            $post_number = $data['ticker_item'];          
            $args = array(
                'post_type' => 'post',
                'post_status'       => 'publish',
                'posts_per_page' => $post_number,
                'post__not_in' => $no_duplicate_post
            );

            if(!empty($data['catid'])){
                if( $data['query_type'] == 'category'){
                    $args['tax_query'] = [
                        [
                            'taxonomy' => 'category',
                            'field' => 'term_id',
                            'terms' => $data['catid'],                    
                        ],
                    ];

                }
            }
            if(!empty($data['postid'])){
                if( $data['query_type'] == 'posts'){
                    $args['post__in'] = $data['postid'];
                }
            }
            
            $the_query = new WP_Query( $args );
            
            while ( $the_query->have_posts() ) {

                $the_query->the_post();
                
                $no_duplicate_post[] = get_the_ID();
            ?>
                <li class="news-item"><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></li>
            <?php }
        wp_reset_postdata();
     ?>
    </ol>
</div>
