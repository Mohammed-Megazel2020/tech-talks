<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Css_Filter;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Image extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Image', 'neeon-core' );
		$this->rt_base = 'rt-image';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Image Style', 'neeon-core' ),
				'options' => array(
					'style1' => esc_html__( 'Style 1' , 'neeon-core' ),
					'style2' => esc_html__( 'Style 2', 'neeon-core' ),
					'style3' => esc_html__( 'Style 3', 'neeon-core' ),
				),
				'default' => 'style1',
			),
			/*image default*/
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'rt_image',
				'label'   => esc_html__( 'Image', 'neeon-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended full image', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style1', 'style3' ) ),
			),
			array(
				'type'    => Group_Control_Css_Filter::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'Image Blend', 'neeon-core' ),	
				'name' => 'blend', 
				'selector' => '{{WRAPPER}} img',		
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'rt_logo',
				'label'   => esc_html__( 'Logo', 'neeon-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended full image', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style3' ) ),
			),	
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'rt_title',
				'label'   => esc_html__( 'Title', 'neeon-core' ),
				'default' => esc_html__( 'The Most Powerful', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style3' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'rt_text',
				'label'   => esc_html__( 'Content', 'neeon-core' ),
				'default' => esc_html__( 'News & Magazine WP Theme', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style3' ) ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'img_list1',
				'label'   => esc_html__( 'Image 1', 'neeon-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended image size 551 X 630', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style2' ) ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'img_list2',
				'label'   => esc_html__( 'Image 2', 'neeon-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended image size 551 X 555', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style2' ) ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'img_list3',
				'label'   => esc_html__( 'Image 3', 'neeon-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended image size 551 X 320', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style2' ) ),
			),
			/*element list*/
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'element1',
				'label'   => esc_html__( 'Element 1', 'neeon-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended image size 73 X 28', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style2' ) ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'element2',
				'label'   => esc_html__( 'Element 1', 'neeon-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended image size 113 X 104', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style2' ) ),
			),	
			
			array(
				'type'    => Group_Control_Image_Size::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'image size', 'neeon-core' ),	
				'name' => 'icon_image_size', 
				'separator' => 'none',		
			),
			/*button*/
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'buttontext',
				'label'   => esc_html__( 'Button Text', 'neeon-core' ),
				'default' => esc_html__( 'SHOP NOW', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style3' ) ),
			),
			array(
				'type'  => Controls_Manager::URL,
				'id'    => 'url',
				'label' => esc_html__( 'Link (Optional)', 'neeon-core' ),
				'placeholder' => 'https://your-link.com',
				'condition'   => array( 'style' => array( 'style1','style3' ) ),
			),
			
			array(
				'type'    => Controls_Manager::DIMENSIONS,
				'id'      => 'border_radius',
				'label'   => esc_html__( 'Border Radius', 'neeon-core' ),
				'size_units' => [ 'px', '%' ],
				'selectors' => [
					'{{WRAPPER}} .rt-image img' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
				'condition'   => array( 'style' => array( 'style1' ) ),
			),
			array(
				'mode' => 'section_end',
			),
			/*Animation section*/
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_animation_style',
	            'label'   => esc_html__( 'Animation', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'neeon-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'neeon-core' ),
					'hide'        => esc_html__( 'Off', 'neeon-core' ),
				),
				'default' => 'wow',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'neeon-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'neeon-core' ),
					'bounce' => esc_html__( 'bounce', 'neeon-core' ),
					'flash' => esc_html__( 'flash', 'neeon-core' ),
					'pulse' => esc_html__( 'pulse', 'neeon-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'neeon-core' ),
					'shakeX' => esc_html__( 'shakeX', 'neeon-core' ),
					'shakeY' => esc_html__( 'shakeY', 'neeon-core' ),
					'headShake' => esc_html__( 'headShake', 'neeon-core' ),
					'swing' => esc_html__( 'swing', 'neeon-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'neeon-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'neeon-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'neeon-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'neeon-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'neeon-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'neeon-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'neeon-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'neeon-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'neeon-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'neeon-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'neeon-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'neeon-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'neeon-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'neeon-core' ), 
                ),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ), 'style' => array( 'style1' ) ),
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		switch ( $data['style'] ) {
			case 'style3':
			$template = 'rt-image-3';
			break;
			case 'style2':
			$template = 'rt-image-2';
			break;
			default:
			$template = 'rt-image-1';
			break;
		}
	
		return $this->rt_template( $template, $data );
	}
}