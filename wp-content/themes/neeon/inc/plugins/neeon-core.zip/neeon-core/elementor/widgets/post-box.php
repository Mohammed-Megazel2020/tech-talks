<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Css_Filter;

if ( ! defined( 'ABSPATH' ) ) exit;

class Post_Box extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Post Box', 'neeon-core' );
		$this->rt_base = 'rt-post-box';
		$this->rt_translate = array(
			'cols'  => array(
				'12' => esc_html__( '1 Col', 'neeon-core' ),
				'6'  => esc_html__( '2 Col', 'neeon-core' ),
				'4'  => esc_html__( '3 Col', 'neeon-core' ),
				'3'  => esc_html__( '4 Col', 'neeon-core' ),
				'2'  => esc_html__( '6 Col', 'neeon-core' ),
			),
		);
		parent::__construct( $data, $args );
	}

	private function rt_load_scripts(){		
		//audio media
        wp_enqueue_style(  'wp-mediaelement');
        wp_enqueue_script( 'wp-mediaelement' );
	}

	public function rt_fields(){
		$repeater = new \Elementor\Repeater();
		$repeater->add_control(
			'post_not_in', array(
				'type'    => Controls_Manager::NUMBER,
				'label'   => __( 'Post ID', 'neeon-core' ),
				'default' => '0',
			)
		);
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Style', 'neeon-core' ),
				'options' => array(
					'style1' => esc_html__( 'Box Layout 1', 'neeon-core' ),
					'style2' => esc_html__( 'Box Layout 2', 'neeon-core' ),
					'style3' => esc_html__( 'Box Layout 3', 'neeon-core' ),
					'style4' => esc_html__( 'Box Layout 4', 'neeon-core' ),
					'style5' => esc_html__( 'Box Layout 5 Podcast', 'neeon-core' ),
					'style6' => esc_html__( 'Box Layout 6 Podcast', 'neeon-core' ),
				),
				'default' => 'style1',
			),
			array(
				'type' => Controls_Manager::CHOOSE,
				'id'      => 'content_align',
				'mode'    => 'responsive',
				'label'   => esc_html__('Alignment', 'neeon-core'),
				'options' => array(
					'left' => array(
						'title' => __('Left', 'elementor'),
						'icon' => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __('Center', 'elementor'),
						'icon' => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => __('Right', 'elementor'),
						'icon' => 'eicon-text-align-right',
					),
				),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'itemlimit',
				'label'   => esc_html__( 'Item Limit', 'neeon-core' ),
				'range' => array(
	                'px' => array(
	                    'min' => 1,
	                    'max' => 12,
	               	),
		       	),
	            'default' => array(
	                'size' => 3,
	            ),
				'description' => esc_html__( 'Maximum number of Item', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'title_count',
				'label'   => esc_html__( 'Title count', 'neeon-core' ),
				'default' => 15,
				'description' => esc_html__( 'Maximum number of title', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'small_title_count',
				'label'   => esc_html__( 'Small Title count', 'neeon-core' ),
				'default' => 10,
				'description' => esc_html__( 'Maximum number of title', 'neeon-core' ),
				'condition'   => array( 'style!' => array( 'style4', 'style5', 'style6' ) ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'item_space',
				'label'   => esc_html__( 'Item Space', 'neeon-core' ),
				'options' => array(
					'g-0' => esc_html__( 'Gutters 0', 'neeon-core' ),
					'g-1' => esc_html__( 'Gutters 1', 'neeon-core' ),
					'g-2' => esc_html__( 'Gutters 2', 'neeon-core' ),
					'g-3' => esc_html__( 'Gutters 3', 'neeon-core' ),
					'g-4' => esc_html__( 'Gutters 4', 'neeon-core' ),
					'g-5' => esc_html__( 'Gutters 5', 'neeon-core' ),
				),
				'default' => 'g-4',
			),			
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'image_thumb_size',
				'label'   => esc_html__( 'Image Size', 'neeon-core' ),
				'options' => array(
					'thumb' => esc_html__( 'Thumb', 'neeon-core' ),
					'full' => esc_html__( 'Full', 'neeon-core' ),
				),
				'default' => 'thumb',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'left_right_order',
				'label'   => esc_html__( 'Left Right Order', 'neeon-core' ),				
				'options' => array(
					'left-order' 		=> esc_html__( 'Left Order', 'neeon-core' ),
					'right-order' 		=> esc_html__( 'Right Order', 'neeon-core' ),
				),
				'default' => 'left-order',
				'condition'   => array( 'style!' => array( 'style4', 'style5', 'style6' ) ),
			),	
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'border_radius',
	            'label'   => __( 'Radius', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-post-box-default .rt-item' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
			array(
				'mode' => 'section_end',
			),
			// Content style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_content_style',
	            'label'   => esc_html__( 'Content Settings', 'neeon-core' ),
	            'condition'   => array( 'style' => array( 'style4', 'style5', 'style6' ) ),
	        ),
	        array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'content_display',
				'label'       => esc_html__( 'Content Display', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'count',
				'label'   => esc_html__( 'Word count', 'neeon-core' ),
				'default' => 20,
				'condition' => array( 'content_display' => array( 'yes' ) ),
				'description' => esc_html__( 'Maximum number of words', 'neeon-core' ),
			),
	        array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'content_typo',
				'label'   => esc_html__( 'Content Typo', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-post-box-default .rt-item .post_excerpt p',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'content_color',
				'label'   => esc_html__( 'Content Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item .post_excerpt' => 'color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'content_margin',
	            'label'   => __( 'Content Margin', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-post-box-default .rt-item .post_excerpt' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'box_paddinr',
	            'label'   => __( 'Box Padding', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-post-box-default .rt-item .entry-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'read_more_text',
				'label'   => esc_html__( 'Read More', 'neeon-core' ),
				'default' => esc_html__( 'Read More', 'neeon-core' ),
			),
			array(
				'mode' => 'section_end',
			),
			/*query option*/
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_query',
				'label'   => esc_html__( 'Query Settings', 'neeon-core' ),
			),
			/*Post Order*/
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'post_orderby',
				'label'   => esc_html__('Post Sorting', 'neeon-core'),
				'options' => array(
					'recent' 		=> esc_html__('Recent Post', 'neeon-core'),
					'popular' 		=> esc_html__('Popular Post', 'neeon-core'),
					'rand' 			=> esc_html__('Random Post', 'neeon-core'),
					'menu_order' 	=> esc_html__('Custom Order', 'neeon-core'),
					'title' 		=> esc_html__('By Name', 'neeon-core'),
				),
				'default' => 'recent',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'post_ordering',
				'label'   => esc_html__('Post Ordering', 'neeon-core'),
				'options' => array(
					'DESC'	=> esc_html__('Desecending', 'neeon-core'),
					'ASC'	=> esc_html__('Ascending', 'neeon-core'),
				),
				'default' => 'DESC',
				'condition' => [
					'post_orderby!' => ['popular'],
				],
			),
			/*Start category*/
			array(
				'id'      => 'query_type',
				'label' => esc_html__( 'Query type', 'neeon-core' ),
            	'type' => Controls_Manager::SELECT,
            	'default' => 'category',
            	'options' => array(
					'category'  => esc_html__( 'Category', 'neeon-core' ),
                	'posts' => esc_html__( 'Posts', 'neeon-core' ),
				),
			),
			array(
				'id'                   => 'postid',
				'type'                 => 'rt-select2',
				'label'                => esc_html__('Selects posts', 'neeon-core'),
				'source_name'          => 'post_type',
				'source_type'          => 'post',
				'multiple'             => true,
				'label_block'          => true,
				'minimum_input_length' => 3,
				'maximum_selection_length' => -1,
				'condition' => array(
					'query_type' => 'posts',
				),
			),
			array(
				'id'      			   => 'catid',
				'type'                 => 'rt-select2',
				'label'                => esc_html__('Categories', 'neeon-core'),
				'source_name'          => 'taxonomy',
				'source_type'          => 'category',
				'multiple'             => true,
				'label_block'          => true,
				'minimum_input_length' => 1,
				'maximum_selection_length' => -1,
				'condition' => array(
					'query_type' => 'category',
				),
			),
			/*post offset*/
	        array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'number_of_post_offset',
				'label'   => __( 'Offset ( No of Posts )', 'neeon-core' ),
				'default' => '0',
				'separator' => 'before',
			),
			array(
				'type'    => Controls_Manager::REPEATER,
				'id'      => 'posts_not_in',
				'label'   => __( 'Exclude Post by ID', 'neeon-core' ),
				'fields' => $repeater->get_controls(),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'sticky_posts',
				'label'   => esc_html__( 'Sticky Posts', 'neeon-core' ),
				'options' => array(
					'1' => esc_html__( 'Off', 'neeon-core' ),
					'0' => esc_html__( 'On', 'neeon-core' ),
				),
				'default' => '1',
			),
			array(
				'mode' => 'section_end',
			),
			// Option
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_style',
				'label'   => esc_html__( 'Meta Option', 'neeon-core' ),
				'tab'     => Controls_Manager::TAB_STYLE,
			),
			// Tab For Normal view.
			array(
				'mode' => 'tabs_start',
				'id'   => 'meta_tabs_start',
			),			
			array(
				'mode'  => 'tab_start',
				'id'    => 'rt_tab_single_post',
				'label' => esc_html__( 'Single Post', 'neeon-core' ),
			),			
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_author',
				'label'       => esc_html__( 'Show Author', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_date',
				'label'       => esc_html__( 'Show Date', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_category',
				'label'       => esc_html__( 'Show Categories', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_comment',
				'label'       => esc_html__( 'Show Comment', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_length',
				'label'       => esc_html__( 'Show Lenght', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_view',
				'label'       => esc_html__( 'Show View', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_video',
				'label'       => esc_html__( 'Show Video', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array (
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_read',
				'label'       => esc_html__( 'Show Read More', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
				'condition'   => array( 'style' => array( 'style4', 'style5', 'style6' ) ),
			),
			array(
				'mode' => 'tab_end',
			),
			// Tab For Hover view.
			array(
				'mode'  => 'tab_start',
				'id'    => 'rt_tab_multi_post',
				'label' => esc_html__( 'Multi Post', 'neeon-core' ),
				'condition'   => array( 'style!' => array( 'style4', 'style5', 'style6' ) ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_author',
				'label'       => esc_html__( 'Show Author', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_date',
				'label'       => esc_html__( 'Show Date', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_category',
				'label'       => esc_html__( 'Show Categories', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_comment',
				'label'       => esc_html__( 'Show Comment', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_length',
				'label'       => esc_html__( 'Show Lenght', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_view',
				'label'       => esc_html__( 'Show View', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'small_post_video',
				'label'       => esc_html__( 'Show Video', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'no',
			),
			array(
				'mode' => 'tab_end',
			),
			array(
				'mode' => 'tabs_end',
			),
			array(
				'type'    => Group_Control_Css_Filter::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'Image Blend', 'neeon-core' ),	
				'name' => 'blend', 
				'selector' => '{{WRAPPER}} img',		
			),	        
			array(
				'mode' => 'section_end',
			),
			// Title style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_title_style',
	            'label'   => esc_html__( 'Title Typo', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
	        array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Style', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-post-box-default .rt-item-grid .entry-title',
			),
			array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_small_typo',
				'label'   => esc_html__( 'Title Small Style', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-post-box-default .rt-item-list .entry-title',
				'condition'   => array( 'style!' => array( 'style4', 'style5', 'style6' ) ),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item-grid .entry-title a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'small_title_color',
				'label'   => esc_html__( 'Small Title Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item-list .entry-title a' => 'color: {{VALUE}}',
				),
				'condition'   => array( 'style!' => array( 'style4', 'style5', 'style6' ) ),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'title_margin',
	            'label'   => __( 'Margin', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-post-box-default .rt-item .entry-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
	        array(
				'type' => Controls_Manager::SELECT,
				'id'      => 'heading_tag',
				'label'   => esc_html__( 'HTML Tag', 'neeon-core' ),
				'options' => array(
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				),
				'default' => 'h3',
			),
			array(
				'mode' => 'section_end',
			),
			// Meta style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_meta_style',
	            'label'   => esc_html__( 'Meta Style', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
	        array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'meta_typo',
				'label'   => esc_html__( 'Meta Typo', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-post-box-default ul.entry-meta li',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'meta_color',
				'label'   => esc_html__( 'Meta Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default ul.entry-meta li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-post-box-default ul.entry-meta li a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'meta_icon_color',
				'label'   => esc_html__( 'Meta Icon Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default ul.entry-meta li i' => 'color: {{VALUE}}',
				),
			),			
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'meta_author_color',
				'label'   => esc_html__( 'Meta Author Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item-grid ul.entry-meta .post-author a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'small_meta_color',
				'label'   => esc_html__( 'Small Meta Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item-list ul.entry-meta li' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-post-box-default .rt-item-list ul.entry-meta li a' => 'color: {{VALUE}}',
					'{{WRAPPER}} .rt-post-box-default .rt-item-list .post-terms a' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'small_meta_icon_color',
				'label'   => esc_html__( 'Small Meta Icon Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item-list ul.entry-meta li i' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'small_meta_author_color',
				'label'   => esc_html__( 'Small Meta Author Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item-list ul.entry-meta .post-author a' => 'color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'meta_margin',
	            'label'   => __( 'Margin', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-post-box-default ul.entry-meta' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
	        array(
				'mode' => 'section_end',
			),
			// Category style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_category_style',
	            'label'   => esc_html__( 'Category Style', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),	        
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'cat_layout',
				'label'   => esc_html__( 'Category Layout', 'neeon-core' ),				
				'options' => array(
					'cat_layout1' 		=> esc_html__( 'Cat Layout 1', 'neeon-core' ),
					'cat_layout2' 		=> esc_html__( 'Cat Layout 2', 'neeon-core' ),
					'cat_layout3' 		=> esc_html__( 'Cat Layout 3', 'neeon-core' ),
				),
				'default' => 'cat_layout1',
			),
	        array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'cat_typo',
				'label'   => esc_html__( 'Category Typo', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-post-box-default .rt-item .post-terms a',
			),			
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'cat_color',
				'label'   => esc_html__( 'Category Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item .rt-cat a' => 'color: {{VALUE}}',
				),
				'condition'   => array( 'cat_layout' => array( 'cat_layout2', 'cat_layout3' ) ),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'cat_bg_color',
				'label'   => esc_html__( 'Category Background Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item .rt-cat-3 a' => 'background-color: {{VALUE}}',
				),
				'condition'   => array( 'cat_layout' => array( 'cat_layout3' ) ),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'cat_border_color',
				'label'   => esc_html__( 'Category Border Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item .rt-cat-3 a' => 'border-color: {{VALUE}}',
				),
				'condition'   => array( 'cat_layout' => array( 'cat_layout3' ) ),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'cat_margin',
	            'label'   => __( 'Margin', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-post-box-default .rt-item .post-terms' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
	        array(
				'mode' => 'section_end',
			),
			// Video Button
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_playbutton_style',
	            'label'   => esc_html__( 'Play Button Style', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'video_layout',
				'label'   => esc_html__( 'Play Button', 'neeon-core' ),				
				'options' => array(
					'play-btn-primary' 			=> esc_html__( 'Play Style 1', 'neeon-core' ),
					'play-btn-white-lg' 		=> esc_html__( 'Play Style 2', 'neeon-core' ),
					'play-btn-white-xl' 		=> esc_html__( 'Play Style 3', 'neeon-core' ),
					'play-btn-transparent' 		=> esc_html__( 'Play Style 4', 'neeon-core' ),
					'play-btn-transparent-2' 	=> esc_html__( 'Play Style 5', 'neeon-core' ),
					'play-btn-transparent-3' 	=> esc_html__( 'Play Style 6', 'neeon-core' ),
				),
				'default' => 'play-btn-white-xl',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'play_button_position',
				'label'   => esc_html__( 'Play Button Position', 'neeon-core' ),				
				'options' => array(
					'play-position-default' => esc_html__( 'Default', 'neeon-core' ),
					'play-position-rb' 		=> esc_html__( 'Right Bottom', 'neeon-core' ),
					'play-position-rt' 		=> esc_html__( 'Right Top', 'neeon-core' ),
					'play-position-lt' 		=> esc_html__( 'Left Top', 'neeon-core' ),
					'play-position-lb' 		=> esc_html__( 'Left Bottom', 'neeon-core' ),
				),
				'default' => 'play-position-default',
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'play_button_width',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Play Button Width', 'neeon-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item .rt-image .rt-play' => 'width: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'play_button_height',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Play Button Height', 'neeon-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item .rt-image .rt-play' => 'height: {{SIZE}}{{UNIT}};',
				),
			),			
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'play_button_radius',
	            'label'   => __( 'Radius', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-post-box-default .rt-item .rt-image .rt-play' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
	            ),
	            'separator' => 'before',
	        ),
	        array(
				'mode' => 'section_end',
			),
			// Audio Button
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_audio_button',
	            'label'   => esc_html__( 'Audio Button', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	            'condition'   => array( 'style' => array( 'style5', 'style6' ) ),
	        ),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'post_audio',
				'label'       => esc_html__( 'Show Audio', 'neeon-core' ),
				'label_on'    => esc_html__( 'Show', 'neeon-core' ),
				'label_off'   => esc_html__( 'Hide', 'neeon-core' ),
				'default'     => 'yes',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'audio_button_position',
				'label'   => esc_html__( 'Audio Button Position', 'neeon-core' ),				
				'options' => array(
					'audio-position-default' => esc_html__( 'Default', 'neeon-core' ),
					'audio-position-rb' 		=> esc_html__( 'Right Bottom', 'neeon-core' ),
					'audio-position-rt' 		=> esc_html__( 'Right Top', 'neeon-core' ),
					'audio-position-lt' 		=> esc_html__( 'Left Top', 'neeon-core' ),
					'audio-position-lb' 		=> esc_html__( 'Left Bottom', 'neeon-core' ),
				),
				'default' => 'audio-position-default',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'audio_button_color',
				'label'   => esc_html__( 'Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container .mejs-button' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'audio_button_hover_color',
				'label'   => esc_html__( 'Hover Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container .mejs-button:hover' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'audio_button_bg_color',
				'label'   => esc_html__( 'Background Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container .mejs-controls' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'audio_button_bg_hover_color',
				'label'   => esc_html__( 'Background Hover Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container .mejs-controls:hover' => 'background-color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'audio_button_width',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Audio Button Width', 'neeon-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container' => 'width: {{SIZE}}{{UNIT}} !important;',
					'{{WRAPPER}} .audio-player .mejs-container .mejs-controls' => 'width: {{SIZE}}{{UNIT}} !important;',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'audio_button_height',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Audio Button Height', 'neeon-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container' => 'height: {{SIZE}}{{UNIT}} !important;',
					'{{WRAPPER}} .audio-player .mejs-container .mejs-controls' => 'height: {{SIZE}}{{UNIT}} !important;',
				),
			),			
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'audio_button_radius',
	            'label'   => __( 'Button Radius', 'neeon-core' ),                 
	            'selectors' => array(
					'{{WRAPPER}} .audio-player .mejs-container' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
					'{{WRAPPER}} .audio-player .mejs-container .mejs-controls' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',
				),
	            'separator' => 'before',
	        ),
	        array(
				'mode' => 'section_end',
			),
			// Image style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_image_style',
	            'label'   => esc_html__( 'Image', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'image_width',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Width', 'neeon-core' ),
				'size_units' => array( '%', 'px', 'vw' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 1000,
					),
					'vw' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item-list .rt-image' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'image_height',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Height', 'neeon-core' ),
				'size_units' => array( '%', 'px', 'vw' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 1000,
					),
					'vw' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-post-box-default .rt-item-list .rt-image img' => 'height: {{SIZE}}{{UNIT}};',
				),
			),
	        array(
				'mode' => 'section_end',
			),
			// Animation style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_animation_style',
	            'label'   => esc_html__( 'Animation', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'neeon-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'neeon-core' ),
					'hide'        => esc_html__( 'Off', 'neeon-core' ),
				),
				'default' => 'wow',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'neeon-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'neeon-core' ),
					'bounce' => esc_html__( 'bounce', 'neeon-core' ),
					'flash' => esc_html__( 'flash', 'neeon-core' ),
					'pulse' => esc_html__( 'pulse', 'neeon-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'neeon-core' ),
					'shakeX' => esc_html__( 'shakeX', 'neeon-core' ),
					'shakeY' => esc_html__( 'shakeY', 'neeon-core' ),
					'headShake' => esc_html__( 'headShake', 'neeon-core' ),
					'swing' => esc_html__( 'swing', 'neeon-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'neeon-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'neeon-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'neeon-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'neeon-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'neeon-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'neeon-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'neeon-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'neeon-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'neeon-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'neeon-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'neeon-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'neeon-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'neeon-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'neeon-core' ), 
                ),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay',
				'label'   => esc_html__( 'Delay', 'neeon-core' ),
				'default' => '0.5',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration',
				'label'   => esc_html__( 'Duration', 'neeon-core' ),
				'default' => '1',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'mode' => 'section_end',
			),
			// Responsive Columns
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_responsive',
				'label'   => esc_html__( 'Number of Responsive Columns', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style4', 'style6' ) ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_xl',
				'label'   => esc_html__( 'Desktops: > 1199px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '4',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_lg',
				'label'   => esc_html__( 'Desktops: > 991px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '4',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_md',
				'label'   => esc_html__( 'Tablets: > 767px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '6',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_sm',
				'label'   => esc_html__( 'Phones: > 576px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '12',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col',
				'label'   => esc_html__( 'Phones: < 576px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '12',
			),
			array(
				'mode' => 'section_end',
			),
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();		

		switch ( $data['style'] ) {
			case 'style6':
			$this->rt_load_scripts();
			$template = 'post-box-5';
			break;
			case 'style5':
			$this->rt_load_scripts();
			$template = 'post-box-4';
			break;
			case 'style4':
			$template = 'post-box-3';
			break;
			case 'style3':
			$template = 'post-box-2';
			break;
			case 'style2':
			$template = 'post-box-1';
			break;
			default:
			$template = 'post-box-1';
			break;
		}
		
		return $this->rt_template( $template, $data );
	}
}