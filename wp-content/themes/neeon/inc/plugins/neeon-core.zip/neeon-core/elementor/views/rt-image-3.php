<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use NeeonTheme_Helper;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
extract($data);

$attr = '';
if ( !empty( $data['url']['url'] ) ) {
	$attr  = 'href="' . $data['url']['url'] . '"';
	$attr .= !empty( $data['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['url']['nofollow'] ) ? ' rel="nofollow"' : '';
	
}
if ( $attr ) {
  $rt_logo = '<a ' . $attr . '>' .Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size' , 'rt_logo' ) . '</a>';
}
else {
	$rt_logo = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'rt_logo' );
}

?>

<div class="rt-image-default rt-image-<?php echo esc_attr( $data['style'] );?>" data-bg-image="<?php echo esc_attr($data['rt_image']['url']); ?>">
	<div class="rt-image <?php echo esc_attr( $data['animation'] );?> <?php echo esc_attr( $data['animation_effect'] );?>" data-wow-delay="1s" data-wow-duration="1.2s">
		<?php if( $rt_logo ) { ?><span class="rt-logo"><?php echo wp_kses_post($rt_logo);?></span><?php } ?>
		<h3><?php echo esc_html( $data['rt_title'] );?></h3>
		<h4><?php echo esc_html( $data['rt_text'] );?></h4>
		<a class="about-btn button-style-2" <?php echo $attr; ?>><?php echo esc_html( $data['buttontext'] );?></a>
	</div>
</div>
