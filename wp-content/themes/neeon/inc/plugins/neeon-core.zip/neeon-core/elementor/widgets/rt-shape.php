<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Image_Size;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Shape extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Shape', 'neeon-core' );
		$this->rt_base = 'rt-shape';
		parent::__construct( $data, $args );
	}
	
	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'layout',
				'label'   => esc_html__( 'Style', 'neeon-core' ),
				'options' => array(
					'layout1' => esc_html__( 'Layout 1', 'neeon-core' ),
					'layout2' => esc_html__( 'Layout 2', 'neeon-core' ),
				),
				'default' => 'layout1',
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'shape_one',
				'label'   => esc_html__( 'Element', 'neeon-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended image size 113 X 104', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::MEDIA,
				'id'      => 'shape_two',
				'label'   => esc_html__( 'Element 2', 'neeon-core' ),
				'default' => array(
                    'url' => Utils::get_placeholder_image_src(),
                ),
				'description' => esc_html__( 'Recommended image size 113 X 104', 'neeon-core' ),
				'condition'   => array( 'layout' => array( 'layout2' ) ),
			),
			array(
				'type'    => Group_Control_Image_Size::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'image size', 'neeon-core' ),	
				'name' => 'icon_image_size', 
				'separator' => 'none',		
			),
			array(
				'mode' => 'section_end',
			),

			/*sub title section*/
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_image_position',
	            'label'   => esc_html__( 'Image Option', 'neeon-core' ),
	            'condition'   => array( 'layout' => array( 'layout2' ) ),
	        ),
			// Tab For Normal view.
			array(
				'mode' => 'tabs_start',
				'id'   => 'meta_tabs_start',
			),			
			array(
				'mode'  => 'tab_start',
				'id'    => 'rt_tab_one_option',
				'label' => esc_html__( 'Shape One', 'neeon-core' ),
			),
	        array(
				'type' 			=> Controls_Manager::SLIDER,
				'mode' 			=> 'responsive',
				'id'      		=> 'shape_left_right',
				'label'   		=> esc_html__( 'Shape Left / Right', 'neeon-core' ),
				'size_units' => array( 'px', '%' ),
				'default' => array(
					'unit' => '%',
					'size' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-shape-layout2 .shape1' => 'left: {{SIZE}}{{UNIT}};',
				)
			),
			array(
				'type' 			=> Controls_Manager::SLIDER,
				'mode' 			=> 'responsive',
				'id'      		=> 'shape_top_bottom',
				'label'   		=> esc_html__( 'Shape Top / Bottom', 'neeon-core' ),
				'size_units' => array( 'px', '%' ),
				'default' => array(
					'unit' => 'px',
					'size' => '',
				),
				'range' => array(
	                'px' => array(
	                    'min' => 0,
	                    'max' => 1000,
	               	),
	               	'%' => array(
	                    'min' => 0,
	                    'max' => 100,
	               	),
		       	),
				'selectors' => array(
					'{{WRAPPER}} .rt-shape-layout2 .shape1' => 'top: {{SIZE}}{{UNIT}};',
				)
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation1',
				'label'   => esc_html__( 'Animation', 'neeon-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'neeon-core' ),
					'hide'        => esc_html__( 'Off', 'neeon-core' ),
				),
				'default' => 'wow',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect1',
				'label'   => esc_html__( 'Entrance Animation', 'neeon-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'neeon-core' ),
					'bounce' => esc_html__( 'bounce', 'neeon-core' ),
					'flash' => esc_html__( 'flash', 'neeon-core' ),
					'pulse' => esc_html__( 'pulse', 'neeon-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'neeon-core' ),
					'shakeX' => esc_html__( 'shakeX', 'neeon-core' ),
					'shakeY' => esc_html__( 'shakeY', 'neeon-core' ),
					'headShake' => esc_html__( 'headShake', 'neeon-core' ),
					'swing' => esc_html__( 'swing', 'neeon-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'neeon-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'neeon-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'neeon-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'neeon-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'neeon-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'neeon-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'neeon-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'neeon-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'neeon-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'neeon-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'neeon-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'neeon-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'neeon-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'neeon-core' ), 
                ),
				'default' => 'fadeInDown',
				'condition'   => array('animation1' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay1',
				'label'   => esc_html__( 'Delay', 'neeon-core' ),
				'default' => '0.5',
				'condition'   => array( 'animation1' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration1',
				'label'   => esc_html__( 'Duration', 'neeon-core' ),
				'default' => '1',
				'condition'   => array( 'animation1' => array( 'wow' ) ),
			),			
			array(
				'mode' => 'tab_end',
			),

			array(
				'mode'  => 'tab_start',
				'id'    => 'rt_tab_two_option',
				'label' => esc_html__( 'Shape Two', 'neeon-core' ),
			),	
			array(
				'type' 			=> Controls_Manager::SLIDER,
				'mode' 			=> 'responsive',
				'id'      		=> 'shape_right_left',
				'label'   		=> esc_html__( 'Shape Left / Right', 'neeon-core' ),						
				'size_units' => array( 'px', '%' ),
				'default' => array(
					'unit' => '%',
					'size' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-shape-layout2 .shape2' => 'right: {{SIZE}}{{UNIT}};',
				)
			),
			array(
				'type' 			=> Controls_Manager::SLIDER,
				'mode' 			=> 'responsive',
				'id'      		=> 'shape_bottom_top',
				'label'   		=> esc_html__( 'Shape Top / Bottom', 'neeon-core' ),
				'size_units' => array( 'px', '%' ),
				'default' => array(
					'unit' => 'px',
					'size' => '',
				),
				'range' => array(
	                'px' => array(
	                    'min' => 0,
	                    'max' => 1000,
	               	),
		       	),
				'selectors' => array(
					'{{WRAPPER}} .rt-shape-layout2 .shape2' => 'top: {{SIZE}}{{UNIT}};',
				)
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation2',
				'label'   => esc_html__( 'Animation', 'neeon-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'neeon-core' ),
					'hide'        => esc_html__( 'Off', 'neeon-core' ),
				),
				'default' => 'wow',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect2',
				'label'   => esc_html__( 'Entrance Animation', 'neeon-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'neeon-core' ),
					'bounce' => esc_html__( 'bounce', 'neeon-core' ),
					'flash' => esc_html__( 'flash', 'neeon-core' ),
					'pulse' => esc_html__( 'pulse', 'neeon-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'neeon-core' ),
					'shakeX' => esc_html__( 'shakeX', 'neeon-core' ),
					'shakeY' => esc_html__( 'shakeY', 'neeon-core' ),
					'headShake' => esc_html__( 'headShake', 'neeon-core' ),
					'swing' => esc_html__( 'swing', 'neeon-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'neeon-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'neeon-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'neeon-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'neeon-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'neeon-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'neeon-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'neeon-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'neeon-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'neeon-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'neeon-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'neeon-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'neeon-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'neeon-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'neeon-core' ), 
                ),
				'default' => 'fadeInRight',
				'condition'   => array('animation2' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay2',
				'label'   => esc_html__( 'Delay', 'neeon-core' ),
				'default' => '0.5',
				'condition'   => array( 'animation2' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration2',
				'label'   => esc_html__( 'Duration', 'neeon-core' ),
				'default' => '1',
				'condition'   => array( 'animation2' => array( 'wow' ) ),
			),
			array(
				'mode' => 'tab_end',
			),
			array(
				'mode' => 'tabs_end',
			),
	        array(
				'mode' => 'section_end',
			),
			
		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		$template = 'rt-shape';

		return $this->rt_template( $template, $data );
	}
}