<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use NeeonTheme_Helper;
use Elementor\Utils;
use Elementor\Group_Control_Image_Size;
extract($data);

$attr = '';
if ( !empty( $data['url']['url'] ) ) {
	$attr  = 'href="' . $data['url']['url'] . '"';
	$attr .= !empty( $data['url']['is_external'] ) ? ' target="_blank"' : '';
	$attr .= !empty( $data['url']['nofollow'] ) ? ' rel="nofollow"' : '';
	
}
//image
$getimg = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'rt_image' );
$getimg1 = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'img_list1' );
$getimg2 = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'img_list2' );
$getimg3 = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'img_list3' );

$element1 = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'element1' );
$element2 = Group_Control_Image_Size::get_attachment_image_html( $data, 'icon_image_size', 'element2' );

?>

<div class="rt-image-default rt-image-<?php echo esc_attr( $data['style'] );?>">
	<div class="rt-image">
		<ul class="rt-img-list">
		  <li class="item item-1 <?php echo esc_attr( $data['animation'] );?> fadeInLeft" data-wow-delay=".3s" data-wow-duration="800ms">
			<?php echo wp_kses_post($getimg1);?>
		  </li>
		  <li class="item item-2 <?php echo esc_attr( $data['animation'] );?> fadeInDown" data-wow-delay=".5s" data-wow-duration="800ms">
			<?php echo wp_kses_post($getimg2);?>
		  </li>
		  <li class="item item-3 <?php echo esc_attr( $data['animation'] );?> fadeInUp" data-wow-delay=".7s" data-wow-duration="800ms">
			<?php echo wp_kses_post($getimg3);?>
		  </li>
		</ul>
		<ul class="rt-shape-list">
		  <li class="item item-1">
			<?php echo wp_kses_post($element1);?>
		  </li>
		  <li class="item item-2">
			<?php echo wp_kses_post($element2);?>
		  </li>
		</ul>
	</div>
</div>