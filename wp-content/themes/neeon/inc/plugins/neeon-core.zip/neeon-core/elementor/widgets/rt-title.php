<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Utils;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Title extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Section Title', 'neeon-core' );
		$this->rt_base = 'rt-title';
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'News Title', 'neeon-core' ),
			),
			/*box title*/
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Title Style', 'neeon-core' ),
				'options' => array(
					'style1' => esc_html__( 'Title Style 1' , 'neeon-core' ),
					'style2' => esc_html__( 'Title Style 2', 'neeon-core' ),
					'style3' => esc_html__( 'Title Style 3', 'neeon-core' ),
					'style4' => esc_html__( 'Title Style 4', 'neeon-core' ),
					'style5' => esc_html__( 'Title Style 5', 'neeon-core' ),
				),
				'default' => 'style1',
			),
			array(
				'type' => Controls_Manager::CHOOSE,
				'id'      => 'content_align',
				'mode'    => 'responsive',
				'label'   => esc_html__( 'Alignment', 'neeon-core' ),
				'options' => array(
					'left' => array(
						'title' => __( 'Left', 'elementor' ),
						'icon' => 'eicon-text-align-left',
					),
					'center' => array(
						'title' => __( 'Center', 'elementor' ),
						'icon' => 'eicon-text-align-center',
					),
					'right' => array(
						'title' => __( 'Right', 'elementor' ),
						'icon' => 'eicon-text-align-right',
					),
					'justify' => array(
						'title' => __( 'Justified', 'elementor' ),
						'icon' => 'eicon-text-align-justify',
					),
				),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}}' => 'text-align: {{VALUE}};',
				),
				'condition'   => array( 'style' => array( 'style2', 'style3' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'title',
				'label'   => esc_html__( 'Title', 'neeon-core' ),
				'default' => 'Welcome To Neeon',
			),
			array(
				'type'    => Controls_Manager::TEXTAREA,
				'id'      => 'sub_title',
				'label'   => esc_html__( 'Sub Title', 'neeon-core' ),
				'default' => esc_html__( 'WHO WE ARE', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style1', 'style2', 'style3' ) ),
			),			
			array(
				'type'    => Controls_Manager::WYSIWYG,
				'id'      => 'content',
				'label'   => esc_html__( 'Content', 'neeon-core' ),
				'default' => esc_html__( 'Grursus mal suada faci lisis Lorem ipsum dolarorit more ametion consectetur elit. Vesti at bulum nec odio aea the dumm rsus consectetur elit.', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style2' ) ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'line_position',
				'label'   => esc_html__( 'Line Position', 'neeon-core' ),
				'options' => array(
					'line-top'        => esc_html__( 'Top', 'neeon-core' ),
					'line-bottom'     => esc_html__( 'Bottom', 'neeon-core' ),
				),
				'default' => 'line-top',
				'condition'   => array( 'style' => array( 'style5' ) ),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'line_width',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Line Width', 'neeon-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 1000,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-section-title.style5 .title-holder .entry-title:before' => 'width: {{SIZE}}{{UNIT}};',
				),
				'condition'   => array( 'style' => array( 'style5' ) ),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'line_height',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Line Height', 'neeon-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 10,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-section-title.style5 .title-holder .entry-title:before' => 'height: {{SIZE}}{{UNIT}};',
				),
				'condition'   => array( 'style' => array( 'style5' ) ),
			),			
			array(
				'type' => Controls_Manager::SELECT,
				'id'      => 'heading_tag',
				'label'   => esc_html__( 'HTML Tag', 'neeon-core' ),
				'options' => array(
					'h1' => 'H1',
					'h2' => 'H2',
					'h3' => 'H3',
					'h4' => 'H4',
					'h5' => 'H5',
					'h6' => 'H6',
					'div' => 'div',
					'span' => 'span',
					'p' => 'p',
				),
				'default' => 'h2',
			),
			array(
				'mode' => 'section_end',
			),

			/*title section*/
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_title_style',
	            'label'   => esc_html__( 'Title', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'title_typo',
				'label'   => esc_html__( 'Title Style', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-section-title .entry-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_color',
				'label'   => esc_html__( 'Title Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-section-title .entry-title' => 'color: {{VALUE}}',
				),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'title_border_color',
				'label'   => esc_html__( 'Title Border Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-section-title .entry-title .titleline' => 'border-color: {{VALUE}}',
					'{{WRAPPER}} .rt-section-title.style5 .entry-title:before' => 'background-color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'title_margin',
	            'label'   => __( 'Title Margin', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-section-title .entry-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),

			array(
				'type'    => Controls_Manager::SLIDER,
				'id'      => 'title_padding',
				'mode'          => 'responsive',
				'label'   => esc_html__( 'Title Padding', 'neeon-core' ),
				'size_units' => array( '%', 'px' ),
				'range' => array(
					'%' => array(
						'min' => 1,
						'max' => 100,
					),
					'px' => array(
						'min' => 1,
						'max' => 100,
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-section-title .entry-title' => 'padding-bottom: {{SIZE}}{{UNIT}};',
				),
			),	
	        array(
				'mode' => 'section_end',
			),

			/*sub title section*/
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_subtitle_style',
	            'label'   => esc_html__( 'Sub Title', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'sub_title_typo',
				'label'   => esc_html__( 'Sub Title Style', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-section-title .sub-title',
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'sub_title_color',
				'label'   => esc_html__( 'Sub Title Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-section-title .sub-title' => 'color: {{VALUE}}',
				),
				'condition'   => array( 'style' => array( 'style1', 'style2', 'style3' ) ),
			),
			array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'sub_title_dot_color',
				'label'   => esc_html__( 'Title Dot Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-section-title.style1 .entry-title .titledot' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-section-title.style2 .sub-title:before' => 'background-color: {{VALUE}}',
					'{{WRAPPER}} .rt-section-title.style3 .sub-title:before' => 'background-color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'sub_title_margin',
	            'label'   => __( 'Margin', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-section-title .sub-title' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
	        array(
				'mode' => 'section_end',
			),

	        /*Content section*/
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_content_style',
	            'label'   => esc_html__( 'Content', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	            'condition'   => array( 'style' => array( 'style2' ) ),
	        ),
	        array (
				'mode'    => 'group',
				'type'    => Group_Control_Typography::get_type(),
				'name'    => 'content_typo',
				'label'   => esc_html__( 'Content Style', 'neeon-core' ),
				'selector' => '{{WRAPPER}} .rt-section-title .entry-text',
			),
	        array(
				'type'    => Controls_Manager::COLOR,
				'id'      => 'content_color',
				'label'   => esc_html__( 'Content Color', 'neeon-core' ),
				'default' => '',
				'selectors' => array(
					'{{WRAPPER}} .rt-section-title .entry-text' => 'color: {{VALUE}}',
				),
			),
			array(
	            'type'    => Controls_Manager::DIMENSIONS,
	            'mode'          => 'responsive',
	            'size_units' => [ 'px', '%', 'em' ],
	            'id'      => 'content_margin',
	            'label'   => __( 'Margin', 'neeon-core' ),                 
	            'selectors' => array(
	                '{{WRAPPER}} .rt-section-title.style2 .entry-text' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}} !important;',                    
	            ),
	            'separator' => 'before',
	        ),
			array(
				'type' 			=> Controls_Manager::SLIDER,
				'mode' 			=> 'responsive',
				'id'      		=> 'content_width',
				'label'   		=> esc_html__( 'Content Width', 'neeon-core' ),						
				'size_units' => array( 'px', '%', 'em' ),
				'default' => array(
				'unit' => '%',
				'size' => '',
				),
				'selectors' => array(
					'{{WRAPPER}} .rt-section-title.style2 .entry-text' => 'width: {{SIZE}}{{UNIT}};',
				)
			),
			array(
				'mode' => 'section_end',
			),
			// Animation style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_animation_style',
	            'label'   => esc_html__( 'Animation', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'neeon-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'neeon-core' ),
					'hide'        => esc_html__( 'Off', 'neeon-core' ),
				),
				'default' => 'hide',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'neeon-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'neeon-core' ),
					'bounce' => esc_html__( 'bounce', 'neeon-core' ),
					'flash' => esc_html__( 'flash', 'neeon-core' ),
					'pulse' => esc_html__( 'pulse', 'neeon-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'neeon-core' ),
					'shakeX' => esc_html__( 'shakeX', 'neeon-core' ),
					'shakeY' => esc_html__( 'shakeY', 'neeon-core' ),
					'headShake' => esc_html__( 'headShake', 'neeon-core' ),
					'swing' => esc_html__( 'swing', 'neeon-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'neeon-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'neeon-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'neeon-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'neeon-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'neeon-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'neeon-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'neeon-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'neeon-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'neeon-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'neeon-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'neeon-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'neeon-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'neeon-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'neeon-core' ), 
                ),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ) ),
			),			
			array(
				'mode' => 'section_end',
			),

		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();

		switch ( $data['style'] ) {
			case 'style5':
			$template = 'title-5';
			break;
			case 'style4':
			$template = 'title-4';
			break;
			case 'style3':
			$template = 'title-3';
			break;
			case 'style2':
			$template = 'title-2';
			break;
			default:
			$template = 'title-1';
			break;
		}

		return $this->rt_template( $template, $data );
	}
}