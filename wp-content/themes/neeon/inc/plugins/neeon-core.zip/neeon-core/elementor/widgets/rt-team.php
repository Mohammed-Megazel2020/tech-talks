<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Css_Filter;

if ( ! defined( 'ABSPATH' ) ) exit;

class RT_Team extends Custom_Widget_Base {

	public function __construct( $data = [], $args = null ){
		$this->rt_name = esc_html__( 'RT Team', 'neeon-core' );
		$this->rt_base = 'rt-team';
		$this->rt_translate = array(
			'cols'  => array(
				'12' => esc_html__( '1 Col', 'neeon-core' ),
				'6'  => esc_html__( '2 Col', 'neeon-core' ),
				'4'  => esc_html__( '3 Col', 'neeon-core' ),
				'3'  => esc_html__( '4 Col', 'neeon-core' ),
				'2'  => esc_html__( '6 Col', 'neeon-core' ),
			),
		);
		parent::__construct( $data, $args );
	}

	public function rt_fields(){
		$terms = get_terms( array( 'taxonomy' => 'neeon_team_category', 'fields' => 'id=>name' ) );
		$category_dropdown = array( '0' => esc_html__( 'All Categories', 'neeon-core' ) );

		foreach ( $terms as $id => $name ) {
			$category_dropdown[$id] = $name;
		}

		$fields = array(
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_general',
				'label'   => esc_html__( 'General', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'style',
				'label'   => esc_html__( 'Style', 'neeon-core' ),
				'options' => array(
					'style1' => esc_html__( 'Team Grid 1', 'neeon-core' ),
					'style2' => esc_html__( 'Team Grid 2', 'neeon-core' ),
					'style3' => esc_html__( 'Team Slider 1', 'neeon-core' ),
					'style4' => esc_html__( 'Team Slider 2', 'neeon-core' ),
				),
				'default' => 'style1',
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'number',
				'label'   => esc_html__( 'Total number of items', 'neeon-core' ),
				'default' => 6,
				'description' => esc_html__( 'Write -1 to show all', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'item_space',
				'label'   => esc_html__( 'Item Space', 'neeon-core' ),
				'options' => array(
					'g-0' => esc_html__( 'Gutters 0', 'neeon-core' ),
					'g-1' => esc_html__( 'Gutters 1', 'neeon-core' ),
					'g-2' => esc_html__( 'Gutters 2', 'neeon-core' ),
					'g-3' => esc_html__( 'Gutters 3', 'neeon-core' ),
					'g-4' => esc_html__( 'Gutters 4', 'neeon-core' ),
					'g-5' => esc_html__( 'Gutters 5', 'neeon-core' ),
				),
				'default' => 'g-4',
				'condition'   => array( 'style' => array( 'style1', 'style2' ) ),
			),			
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'cat',
				'label'   => esc_html__( 'Categories', 'neeon-core' ),
				'options' => $category_dropdown,
				'default' => '0',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'orderby',
				'label'   => esc_html__( 'Order By', 'neeon-core' ),
				'options' => array(
					'date'        => esc_html__( 'Date (Recents comes first)', 'neeon-core' ),
					'title'       => esc_html__( 'Title', 'neeon-core' ),
					'menu_order'  => esc_html__( 'Custom Order (Available via Order field inside Page Attributes box)', 'neeon-core' ),
				),
				'default' => 'date',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'contype',
				'label'   => esc_html__( 'Content Type', 'neeon-core' ),
				'options' => array(
					'content' => esc_html__( 'Conents', 'neeon-core' ),
					'excerpt' => esc_html__( 'Excerpts', 'neeon-core' ),
				),
				'default'     => 'content',
				'description' => esc_html__( 'Display contents from Editor or Excerpt field', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'count',
				'label'   => esc_html__( 'Word count', 'neeon-core' ),
				'default' => 12,
				'description' => esc_html__( 'Maximum number of words', 'neeon-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'content_display',
				'label'       => esc_html__( 'Content Display', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'no',
				'description' => esc_html__( 'Show or Hide Content. Default: off', 'neeon-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'designation_display',
				'label'       => esc_html__( 'Designation Display', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Show or Hide Designation. Default: On', 'neeon-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'social_display',
				'label'       => esc_html__( 'Social Media Display', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Show or Hide Social Medias. Default: On', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'more_button',
				'label'   => esc_html__( 'More Button', 'neeon-core' ),
				'options' => array(
					'show'        => esc_html__( 'Show Read More', 'neeon-core' ),
					'hide'        => esc_html__( 'Show Pagination', 'neeon-core' ),
				),
				'default' => 'show',
				'condition'   => array( 'style' => array( 'style1', 'style2' ) ),
			),
			array (
				'type'    => Controls_Manager::TEXT,
				'id'      => 'see_button_text',
				'label'   => esc_html__( 'Button Text', 'neeon-core' ),
				'condition'   => array( 'more_button' => array( 'show' ) ),
				'default' => esc_html__( 'More Teams', 'neeon-core' ),
				'condition'   => array( 'more_button' => array( 'show' ), 'style' => array( 'style1', 'style2' ) ),
			),
			array (
				'type'    => Controls_Manager::TEXT,
				'id'      => 'see_button_link',
				'label'   => esc_html__( 'Button Link', 'neeon-core' ),
				'condition'   => array( 'more_button' => array( 'show' ), 'style' => array( 'style1', 'style2' ) ),
			),
			array(
				'mode' => 'section_end',
			),
			// Animation style
			array(
	            'mode'    => 'section_start',
	            'id'      => 'sec_animation_style',
	            'label'   => esc_html__( 'Animation', 'neeon-core' ),
	            'tab'     => Controls_Manager::TAB_STYLE,
	        ),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation',
				'label'   => esc_html__( 'Animation', 'neeon-core' ),
				'options' => array(
					'wow'        => esc_html__( 'On', 'neeon-core' ),
					'hide'        => esc_html__( 'Off', 'neeon-core' ),
				),
				'default' => 'wow',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'animation_effect',
				'label'   => esc_html__( 'Entrance Animation', 'neeon-core' ),
				'options' => array(
                    'none' => esc_html__( 'none', 'neeon-core' ),
					'bounce' => esc_html__( 'bounce', 'neeon-core' ),
					'flash' => esc_html__( 'flash', 'neeon-core' ),
					'pulse' => esc_html__( 'pulse', 'neeon-core' ),
					'rubberBand' => esc_html__( 'rubberBand', 'neeon-core' ),
					'shakeX' => esc_html__( 'shakeX', 'neeon-core' ),
					'shakeY' => esc_html__( 'shakeY', 'neeon-core' ),
					'headShake' => esc_html__( 'headShake', 'neeon-core' ),
					'swing' => esc_html__( 'swing', 'neeon-core' ),					
					'fadeIn' => esc_html__( 'fadeIn', 'neeon-core' ),
					'fadeInDown' => esc_html__( 'fadeInDown', 'neeon-core' ),
					'fadeInLeft' => esc_html__( 'fadeInLeft', 'neeon-core' ),
					'fadeInRight' => esc_html__( 'fadeInRight', 'neeon-core' ),
					'fadeInUp' => esc_html__( 'fadeInUp', 'neeon-core' ),					
					'bounceIn' => esc_html__( 'bounceIn', 'neeon-core' ),
					'bounceInDown' => esc_html__( 'bounceInDown', 'neeon-core' ),
					'bounceInLeft' => esc_html__( 'bounceInLeft', 'neeon-core' ),
					'bounceInRight' => esc_html__( 'bounceInRight', 'neeon-core' ),
					'bounceInUp' => esc_html__( 'bounceInUp', 'neeon-core' ),			
					'slideInDown' => esc_html__( 'slideInDown', 'neeon-core' ),
					'slideInLeft' => esc_html__( 'slideInLeft', 'neeon-core' ),
					'slideInRight' => esc_html__( 'slideInRight', 'neeon-core' ),
					'slideInUp' => esc_html__( 'slideInUp', 'neeon-core' ), 
                ),
				'default' => 'fadeInUp',
				'condition'   => array('animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'delay',
				'label'   => esc_html__( 'Delay', 'neeon-core' ),
				'default' => '0.5',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Controls_Manager::TEXT,
				'id'      => 'duration',
				'label'   => esc_html__( 'Duration', 'neeon-core' ),
				'default' => '1',
				'condition'   => array( 'animation' => array( 'wow' ) ),
			),
			array(
				'type'    => Group_Control_Css_Filter::get_type(),
				'mode'    => 'group',				
				'label'   => esc_html__( 'Image Blend', 'neeon-core' ),	
				'name' => 'blend', 
				'selector' => '{{WRAPPER}} .team-item .team-thums img',		
			),
			array(
				'mode' => 'section_end',
			),

			// Responsive Grid Columns
			array(
				'mode'    => 'section_start',
				'id'      => 'sec_responsive',
				'label'   => esc_html__( 'Number of Responsive Columns', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style1', 'style2' ) ),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_lg',
				'label'   => esc_html__( 'Desktops: > 1199px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '4',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_md',
				'label'   => esc_html__( 'Desktops: > 991px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '4',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_sm',
				'label'   => esc_html__( 'Tablets: > 767px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '6',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_xs',
				'label'   => esc_html__( 'Phones: < 768px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '12',
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'col_mobile',
				'label'   => esc_html__( 'Small Phones: < 480px', 'neeon-core' ),
				'options' => $this->rt_translate['cols'],
				'default' => '12',
			),
			array(
				'mode' => 'section_end',
			),

			// Responsive Slider Columns
			array(
				'mode'        => 'section_start',
				'id'          => 'sec_slider_pervice',
				'label'       => esc_html__( 'PerView Options', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style3', 'style4' ) ),
			),
			
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'desktop',
				'label'   => esc_html__( 'Desktops: > 1600px', 'neeon-core' ),
				'default' => '4',
				'options' => array(
					'1' => esc_html__( '1', 'neeon-core' ),
					'2' => esc_html__( '2', 'neeon-core' ),
					'3' => esc_html__( '3',  'neeon-core' ),
					'4' => esc_html__( '4',  'neeon-core' ),
				),
			),

			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'md_desktop',
				'label'   => esc_html__( 'Desktops: > 1200px', 'neeon-core' ),
				'default' => '3',
				'options' => array(
					'1' => esc_html__( '1', 'neeon-core' ),
					'2' => esc_html__( '2', 'neeon-core' ),
					'3' => esc_html__( '3',  'neeon-core' ),
					'4' => esc_html__( '4',  'neeon-core' ),
				),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'sm_desktop',
				'label'   => esc_html__( 'Desktops: > 992px', 'neeon-core' ),
				'default' => '2',
				'options' => array(
					'1' => esc_html__( '1', 'neeon-core' ),
					'2' => esc_html__( '2', 'neeon-core' ),
					'3' => esc_html__( '3',  'neeon-core' ),
					'4' => esc_html__( '4',  'neeon-core' ),
				),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'tablet',
				'label'   => esc_html__( 'Tablets: > 768px', 'neeon-core' ),
				'default' => '2',
				'options' => array(
					'1' => esc_html__( '1', 'neeon-core' ),
					'2' => esc_html__( '2', 'neeon-core' ),
					'3' => esc_html__( '3',  'neeon-core' ),
				),
			),
			array(
				'type'    => Controls_Manager::SELECT2,
				'id'      => 'mobile',
				'label'   => esc_html__( 'Phones: > 576px', 'neeon-core' ),
				'default' => '1',
				'options' => array(
					'1' => esc_html__( '1', 'neeon-core' ),
					'2' => esc_html__( '2', 'neeon-core' ),
					'3' => esc_html__( '3',  'neeon-core' ),
					'4' => esc_html__( '4',  'neeon-core' ),
				),
			),
			array(
				'mode' => 'section_end',
			),
			
			// Slider options
			array(
				'mode'        => 'section_start',
				'id'          => 'sec_slider',
				'label'       => esc_html__( 'Slider Options', 'neeon-core' ),
				'condition'   => array( 'style' => array( 'style3', 'style4' ) ),
			),			
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'slider_autoplay',
				'label'       => esc_html__( 'Autoplay', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Enable or disable autoplay. Default: On', 'neeon-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'display_arrow',
				'label'       => esc_html__( 'Navigation Arrow', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Navigation Arrow. Default: On', 'neeon-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'display_buttet',
				'label'       => esc_html__( 'Pagination', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Navigation Arrow. Default: On', 'neeon-core' ),
			),
			array(
				'type'    => Controls_Manager::SLIDER,
				'mode' 			=> 'responsive',
				'id'      => 'slides_per_group',
				'label'   => esc_html__( 'slides Per Group', 'neeon-core' ),
				'default' => array(
					'size' => 1,
				),
				'description' => esc_html__( 'slides Per Group. Default: 1', 'neeon-core' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'centered_slides',
				'label'       => esc_html__( 'Centered Slides', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Centered Slides. Default: On', 'neeon-core' ),
				
			),
			array(
				'type'        => Controls_Manager::NUMBER,
				'id'          => 'slides_space',
				'label'       => esc_html__( 'Slides Space', 'neeon-core' ),
				'default'     => 10,
				'description' => esc_html__( 'Slides Space. Default: 10', 'neeon-core' ),
			),		
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'slider_autoplay_delay',
				'label'   => esc_html__( 'Autoplay Slide Delay', 'neeon-core' ),
				'default' => 5000,
				'description' => esc_html__( 'Set any value for example 5 seconds to play it in every 5 seconds. Default: 5 Seconds', 'neeon-core' ),
				'condition'   => array( 'slider_autoplay' => 'yes' ),
			),
			array(
				'type'    => Controls_Manager::NUMBER,
				'id'      => 'slider_autoplay_speed',
				'label'   => esc_html__( 'Autoplay Slide Speed', 'neeon-core' ),
				'default' => 1000,
				'description' => esc_html__( 'Set any value for example .8 seconds to play it in every 2 seconds. Default: .8 Seconds', 'neeon-core' ),
				'condition'   => array( 'slider_autoplay' => 'yes' ),
			),
			array(
				'type'        => Controls_Manager::SWITCHER,
				'id'          => 'slider_loop',
				'label'       => esc_html__( 'Loop', 'neeon-core' ),
				'label_on'    => esc_html__( 'On', 'neeon-core' ),
				'label_off'   => esc_html__( 'Off', 'neeon-core' ),
				'default'     => 'yes',
				'description' => esc_html__( 'Loop to first item. Default: On', 'neeon-core' ),
			),			
			array(
				'mode' => 'section_end',
			),

		);
		return $fields;
	}

	protected function render() {
		$data = $this->get_settings();
		if($data['slider_autoplay']=='yes'){
			$data['slider_autoplay']=true;
		}
		else{
			$data['slider_autoplay']=false;
		}

		$swiper_data = array(
			'slidesPerView' 	=>2,
			'centeredSlides'	=>$data['centered_slides']=='yes' ? true:false ,
			'loop'				=>$data['slider_loop']=='yes' ? true:false,
			'spaceBetween'		=>$data['slides_space'],
			'slidesPerGroup'	=>$data['slides_per_group']['size'],
			'slideToClickedSlide' =>true,
			'autoplay'				=>array(
				'delay'  => $data['slider_autoplay_delay'],
			),
			'speed'      =>$data['slider_autoplay_speed'],
			'breakpoints' =>array(
				'0'    =>array('slidesPerView' =>1),
				'576'    =>array('slidesPerView' =>$data['mobile']),
				'768'    =>array('slidesPerView' =>$data['tablet']),
				'992'    =>array('slidesPerView' =>$data['sm_desktop']),
				'1200'    =>array('slidesPerView' =>$data['md_desktop']),				
				'1600'    =>array('slidesPerView' =>$data['desktop'])
			),
			'auto'   =>$data['slider_autoplay']
		);
		
		
		switch ( $data['style'] ) {
			case 'style4':
			$template = 'team-slider-2';
			break;
			case 'style3':
			$template = 'team-slider-1';
			break;
			case 'style2':
			$template = 'team-grid-2';
			break;
			default:
			$template = 'team-grid-1';
			break;
		}
		
		$data['swiper_data'] = json_encode( $swiper_data );   

		return $this->rt_template( $template, $data );
	}
}