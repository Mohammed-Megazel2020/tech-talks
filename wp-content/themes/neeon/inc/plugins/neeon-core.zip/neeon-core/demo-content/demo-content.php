<?php
/**
 * OCDI Demo importer configuration.
 *
 * @package RT\NeeonCore
 */

use FluentForm\App\Models\Form;
use FluentForm\App\Models\FormMeta;
use FluentForm\Framework\Support\Arr;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * OCDI Demo importer configuration.
 */
class RTDemoimport {
	/**
	 * CLass constructor.
	 */
	public function __construct() {
		// Action Hooks.
		add_action( 'admin_enqueue_scripts', [ $this, 'custom_admin_css' ] );
		add_action( 'ocdi/after_import', [ $this, 'after_import_actions' ] );

		// Filter Hooks.
		add_filter( 'ocdi/import_files', [ $this, 'import_files' ] );
		add_filter( 'ocdi/plugin_page_setup', [ $this, 'import_page_setup' ] );
		add_filter( 'ocdi/plugin_intro_text', [ $this, 'intro_text' ] );
	}

	/**
	 * Demo contains file loading methods
	 *
	 * @return array
	 */
	public function import_files() {
		$demos_array = array(
			'demo1' => array(
				'title'             => __( 'Home 01 – Main', 'neeon-core' ),
				'page'              => __( 'Home 01', 'neeon-core' ),
				'categories'        => [ 'Column 01' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/1.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/',
			),
			'demo2' => array(
				'title'             => __( 'Home 02 – Technology', 'neeon-core' ),
				'page'              => __( 'Home 02', 'neeon-core' ),
				'categories'        => [ 'Column 01' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/2.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-02/',
			),
			'demo3' => array(
				'title'             => __( 'Home 03 – Gaming', 'neeon-core' ),
				'page'              => __( 'Home 03', 'neeon-core' ),
				'categories'        => [ 'Column 01' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/3.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-03/',
			),
			'demo4' => array(
				'title'             => __( 'Home 04 – Illustration', 'neeon-core' ),
				'page'              => __( 'Home 04', 'neeon-core' ),
				'categories'        => [ 'Column 01' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/4.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-04/',
			),
			'demo5' => array(
				'title'             => __( 'Home 05 – Newspaper', 'neeon-core' ),
				'page'              => __( 'Home 05', 'neeon-core' ),
				'categories'        => [ 'Column 01' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/5.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-05/',
			),
			'demo6' => array(
				'title'             => __( 'Home 06 – Magazine', 'neeon-core' ),
				'page'              => __( 'Home 06', 'neeon-core' ),
				'categories'        => [ 'Column 01' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/6.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-06/',
			),
			'demo7' => array(
				'title'             => __( 'Home 07 – Sports', 'neeon-core' ),
				'page'              => __( 'Home 07', 'neeon-core' ),
				'categories'        => [ 'Column 01' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/7.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-07/',
			),
			'demo8' => array(
				'title'             => __( 'Home 08 – Travels', 'neeon-core' ),
				'page'              => __( 'Home 08', 'neeon-core' ),
				'categories'        => [ 'Column 02' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/8.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-08/',
			),
			'demo9' => array(
				'title'             => __( 'Home 09 – Fitness', 'neeon-core' ),
				'page'              => __( 'Home 09', 'neeon-core' ),
				'categories'        => [ 'Column 02' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/9.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-09/',
			),
			'demo10' => array(
				'title'             => __( 'Home 10 – Medical', 'neeon-core' ),
				'page'              => __( 'Home 10', 'neeon-core' ),
				'categories'        => [ 'Column 02' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/10.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-10/',
			),
			'demo11' => array(
				'title'             => __( 'Home 11 – Business', 'neeon-core' ),
				'page'              => __( 'Home 11', 'neeon-core' ),
				'categories'        => [ 'Column 02' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/11.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-11/',
			),
			'demo12' => array(
				'title'             => __( 'Home 12 – Personal', 'neeon-core' ),
				'page'              => __( 'Home 12', 'neeon-core' ),
				'categories'        => [ 'Column 02' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/12.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-12/',
			),
			'demo13' => array(
				'title'             => __( 'Home 13 – Food', 'neeon-core' ),
				'page'              => __( 'Home 13', 'neeon-core' ),
				'categories'        => [ 'Column 02' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/13.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-13/',
			),
			'demo14' => array(
				'title'             => __( 'Home 14 – Photography', 'neeon-core' ),
				'page'              => __( 'Home 14', 'neeon-core' ),
				'categories'        => [ 'Column 02' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/14.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-14/',
			),
			'demo15' => array(
				'title'             => __( 'Home 15 – Animals', 'neeon-core' ),
				'page'              => __( 'Home 15', 'neeon-core' ),
				'categories'        => [ 'Column 03' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/15.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-15/',
			),
			'demo16' => array(
				'title'             => __( 'Home 16 – Music', 'neeon-core' ),
				'page'              => __( 'Home 16', 'neeon-core' ),
				'categories'        => [ 'Column 03' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/16.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-16/',
			),
			'demo17' => array(
				'title'             => __( 'Home 17 – Newsblog', 'neeon-core' ),
				'page'              => __( 'Home 17', 'neeon-core' ),
				'categories'        => [ 'Column 03' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/17.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-17/',
			),
			'demo18' => array(
				'title'             => __( 'Home 18 – Neeontimes', 'neeon-core' ),
				'page'              => __( 'Home 18', 'neeon-core' ),
				'categories'        => [ 'Column 03' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/18.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-18/',
			),
			'demo19' => array(
				'title'             => __( 'Home 19 – Gadget', 'neeon-core' ),
				'page'              => __( 'Home 19', 'neeon-core' ),
				'categories'        => [ 'Column 03' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/19.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-19/',
			),
			'demo20' => array(
				'title'             => __( 'Home 20 – Automotive', 'neeon-core' ),
				'page'              => __( 'Home 20', 'neeon-core' ),
				'categories'        => [ 'Column 03' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/20.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-20/',
			),
			'demo21' => array(
				'title'             => __( 'Home 21 – Crypto', 'neeon-core' ),
				'page'              => __( 'Home 21', 'neeon-core' ),
				'categories'        => [ 'Column 03' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/21.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-21/',
			),
			'demo22' => array(
				'title'             => __( 'Home 22 – Obituaries', 'neeon-core' ),
				'page'              => __( 'Home 22', 'neeon-core' ),
				'categories'        => [ 'Column 04' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/22.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-22/',
			),
			'demo23' => array(
				'title'             => __( 'Home 23 – Videoblog', 'neeon-core' ),
				'page'              => __( 'Home 23', 'neeon-core' ),
				'categories'        => [ 'Column 04' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/23.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-23/',
			),
			'demo24' => array(
				'title'             => __( 'Home 24 – Furniture', 'neeon-core' ),
				'page'              => __( 'Home 24', 'neeon-core' ),
				'categories'        => [ 'Column 04' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/24.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-24/',
			),
			'demo25' => array(
				'title'             => __( 'Home 25 – Finance', 'neeon-core' ),
				'page'              => __( 'Home 25', 'neeon-core' ),
				'categories'        => [ 'Column 04' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/25.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-25/',
			),
			'demo26' => array(
				'title'             => __( 'Home 26 – Podcast', 'neeon-core' ),
				'page'              => __( 'Home 26', 'neeon-core' ),
				'categories'        => [ 'Column 04' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/26.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-26/',
			),
			'demo27' => array(
				'title'             => __( 'Home 27 – Movie', 'neeon-core' ),
				'page'              => __( 'Home 27', 'neeon-core' ),
				'categories'        => [ 'Column 04' ],
				'screenshot'        => RDTHEME_CORE_BASE_URL . 'screenshots/27.jpg',
				'preview_link'      => 'https://radiustheme.com/demo/wordpress/themes/neeon/home-27/',
			),
        );

		$config = array();
		$import_path  = trailingslashit( RDTHEME_CORE_DEMO_CONTENT ) . 'demo/';

		foreach ( $demos_array as $key => $demo ) {
			$config[] = array(
				'import_file_id'                => $key,
				'import_file_name'              => $demo['title'],
				'import_page_name'              => $demo['page'],
				'categories'                    => $demo['categories'],
				'local_import_file'             => $import_path . 'content.xml',
				'local_import_widget_file'      => $import_path . 'widgets.wie',
				'local_import_customizer_file'  => $import_path . 'export.dat',
				'import_preview_image_url'      => $demo['screenshot'],
				'preview_url'                   => $demo['preview_link'],
			);
		}
		return $config;
	}

	/**
	 * Enqueues a custom CSS file specifically for the "Install Demos" admin page.
	 *
	 * @param string $hook_suffix The current admin page hook suffix.
	 *
	 * @return void
	 */
	public function custom_admin_css( $hook_suffix ) {
		if ( 'appearance_page_install_demos' === $hook_suffix ) {
			wp_enqueue_style( 'custom-admin-css', NEEON_CORE_BASE_URL . '/demo-content/css/main.css', [], '1.0.0' );
		}
	}

	/**
	 * After import actions.
	 *
	 * @param array $selected_import Import array.
	 *
	 * @return void
	 */
	public function after_import_actions( $selected_import ) {
		$this
			->set_menus($selected_import['import_file_id'])
			->set_front_page($selected_import)
			->set_elementor_active_kit()
			->set_elementor_settings()
			->set_draft_post()
			->set_social_data()
			->import_fluent_forms( $selected_import );

        update_option( 'permalink_structure', '/%postname%/' );

		flush_rewrite_rules();
	}

	/**
     * Social settings import.
     *
	 * @return RTDemoimport
	 */
    public function set_social_data() {
        $social_data = [
            'wp_social_onboard_status'       => 'a:1:{s:6:"social";a:15:{s:8:"facebook";a:1:{s:6:"enable";s:0:"";}s:7:"twitter";a:1:{s:6:"enable";s:0:"";}s:8:"linkedin";a:1:{s:6:"enable";s:0:"";}s:9:"pinterest";a:1:{s:6:"enable";s:0:"";}s:18:"facebook-messenger";a:1:{s:6:"enable";s:0:"";}s:3:"kik";a:1:{s:6:"enable";s:0:"";}s:5:"skype";a:1:{s:6:"enable";s:0:"";}s:6:"trello";a:1:{s:6:"enable";s:0:"";}s:5:"viber";a:1:{s:6:"enable";s:0:"";}s:8:"whatsapp";a:1:{s:6:"enable";s:0:"";}s:8:"telegram";a:1:{s:6:"enable";s:0:"";}s:5:"email";a:1:{s:6:"enable";s:0:"";}s:6:"reddit";a:1:{s:6:"enable";s:0:"";}s:4:"digg";a:1:{s:6:"enable";s:0:"";}s:11:"stumbleupon";a:1:{s:6:"enable";s:0:"";}}}',
            'xs_share_providers_data'        => 'a:1:{s:6:"social";a:15:{s:8:"facebook";a:1:{s:6:"enable";s:0:"";}s:7:"twitter";a:1:{s:6:"enable";s:0:"";}s:8:"linkedin";a:1:{s:6:"enable";s:0:"";}s:9:"pinterest";a:1:{s:6:"enable";s:0:"";}s:18:"facebook-messenger";a:1:{s:6:"enable";s:0:"";}s:3:"kik";a:1:{s:6:"enable";s:0:"";}s:5:"skype";a:1:{s:6:"enable";s:0:"";}s:6:"trello";a:1:{s:6:"enable";s:0:"";}s:5:"viber";a:1:{s:6:"enable";s:0:"";}s:8:"whatsapp";a:1:{s:6:"enable";s:0:"";}s:8:"telegram";a:1:{s:6:"enable";s:0:"";}s:5:"email";a:1:{s:6:"enable";s:0:"";}s:6:"reddit";a:1:{s:6:"enable";s:0:"";}s:4:"digg";a:1:{s:6:"enable";s:0:"";}s:11:"stumbleupon";a:1:{s:6:"enable";s:0:"";}}}',
            'xs_providers_enabled_counter'   => 'a:9:{s:8:"facebook";a:1:{s:6:"enable";i:1;}s:7:"twitter";a:1:{s:6:"enable";i:1;}s:9:"pinterest";a:1:{s:6:"enable";i:1;}s:8:"dribbble";a:1:{s:6:"enable";i:1;}s:9:"instagram";a:1:{s:6:"enable";i:1;}s:7:"youtube";a:1:{s:6:"enable";i:1;}s:9:"mailchimp";a:1:{s:6:"enable";s:0:"";}s:8:"comments";a:1:{s:6:"enable";s:0:"";}s:5:"posts";a:1:{s:6:"enable";s:0:"";}}',
            'xs_global_setting_data'         => 'a:2:{s:13:"wp_login_page";a:1:{s:6:"enable";i:0;}s:25:"email_new_registered_user";a:1:{s:6:"enable";i:0;}}',
            'xs_share_global_setting_data'   => 'a:1:{s:20:"show_font_from_theme";i:0;}',
            'xs_style_setting_data_share'    => 'a:2:{s:12:"main_content";a:1:{s:23:"show_social_count_share";i:0;}s:13:"fixed_display";a:1:{s:23:"show_social_count_share";i:0;}}',
            'xs_counter_global_setting_data' => 'a:2:{s:6:"global";a:1:{s:5:"cache";s:2:"12";}s:20:"show_font_from_theme";s:1:"1";}',
            'xs_providers_enabled_share'     => 'a:15:{s:8:"facebook";a:1:{s:6:"enable";s:0:"";}s:7:"twitter";a:1:{s:6:"enable";s:0:"";}s:8:"linkedin";a:1:{s:6:"enable";s:0:"";}s:9:"pinterest";a:1:{s:6:"enable";s:0:"";}s:18:"facebook-messenger";a:1:{s:6:"enable";s:0:"";}s:3:"kik";a:1:{s:6:"enable";s:0:"";}s:5:"skype";a:1:{s:6:"enable";s:0:"";}s:6:"trello";a:1:{s:6:"enable";s:0:"";}s:5:"viber";a:1:{s:6:"enable";s:0:"";}s:8:"whatsapp";a:1:{s:6:"enable";s:0:"";}s:8:"telegram";a:1:{s:6:"enable";s:0:"";}s:5:"email";a:1:{s:6:"enable";s:0:"";}s:6:"reddit";a:1:{s:6:"enable";s:0:"";}s:4:"digg";a:1:{s:6:"enable";s:0:"";}s:11:"stumbleupon";a:1:{s:6:"enable";s:0:"";}}',
            'xs_counter_options'             => 'a:1:{s:4:"data";a:6:{s:8:"facebook";i:0;s:7:"twitter";i:0;s:9:"pinterest";i:0;s:8:"dribbble";i:0;s:9:"instagram";i:0;s:7:"youtube";i:0;}}',
            'xs_counter_providers_data'      => 'a:2:{s:6:"social";a:9:{s:8:"facebook";a:2:{s:5:"label";s:8:"Facebook";s:4:"data";a:2:{s:4:"text";s:4:"Fans";s:3:"url";s:26:"http://www.facebook.com/%s";}}s:7:"twitter";a:2:{s:5:"label";s:7:"Twitter";s:4:"data";a:2:{s:4:"text";s:9:"Followers";s:3:"url";s:21:"http://twitter.com/%s";}}s:9:"pinterest";a:2:{s:5:"label";s:9:"Pinterest";s:4:"data";a:2:{s:4:"text";s:9:"Followers";s:3:"url";s:27:"http://www.pinterest.com/%s";}}s:8:"dribbble";a:2:{s:5:"label";s:8:"Dribbble";s:4:"data";a:2:{s:4:"text";s:9:"Followers";s:3:"url";s:22:"http://dribbble.com/%s";}}s:9:"instagram";a:2:{s:5:"label";s:9:"Instagram";s:4:"data";a:2:{s:4:"text";s:9:"Followers";s:3:"url";s:23:"http://instagram.com/%s";}}s:7:"youtube";a:2:{s:5:"label";s:7:"YouTube";s:4:"data";a:2:{s:4:"text";s:11:"Subscribers";s:3:"url";s:24:"http://youtube.com/%s/%s";}}s:9:"mailchimp";a:2:{s:5:"label";s:9:"Mailchimp";s:4:"data";a:1:{s:4:"text";s:11:"Subscribers";}}s:8:"comments";a:2:{s:5:"label";s:8:"Comments";s:4:"data";a:1:{s:4:"text";s:5:"Count";}}s:5:"posts";a:2:{s:5:"label";s:5:"Posts";s:4:"data";a:1:{s:4:"text";s:5:"Count";}}}s:5:"cache";i:5;}',
        ];

        update_option( 'wp_social_onboard_status', 'onboarded' );

        foreach( $social_data as $key => $data ) {
	        update_option( $key, maybe_unserialize( $data ) );
        }

        return $this;
    }

	private function set_menus($selected_import) {
		$mainMenu = get_term_by( 'name', 'Primary Menu', 'nav_menu' );
		$topRight  = get_term_by( 'name', 'Primary Menu', 'nav_menu' );
		set_theme_mod(
			'nav_menu_locations',
			[
				'primary' => $mainMenu->term_id,
				'topright' => $topRight->term_id,
			]
		);

		return $this;
	}

	/**
	 * Assign front page and posts page (blog page).
	 *
	 * @return RTDemoimport
	 */
	private function set_front_page($selected_import) {
		$front_page_id = $this->get_page_by_title( $selected_import['import_page_name'], 'page' );

		update_option( 'show_on_front', 'page' );
		update_option( 'page_on_front', $front_page_id->ID );

		$blog_page_id = $this->get_page_by_title( 'Blog' );
		update_option( 'page_for_posts', $blog_page_id->ID );
		return $this;
	}

	/**
	 * Sets the active Elementor kit.
	 *
	 * @return RTDemoimport
	 */
	private function set_elementor_active_kit() {
		if ( ! is_plugin_active( 'fluentform/fluentform.php' ) ) {
			return $this;
		}

		global $wpdb;

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$pageIds = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT ID FROM $wpdb->posts WHERE (post_name = %s OR post_title = %s) AND post_type = 'elementor_library' AND post_status = 'publish'",
				'default-kit',
				'Default Kit'
			)
		);

		if ( ! is_null( $pageIds ) ) {
			$pageId    = 0;
			$deleteIds = [];

			// Retrieve page with greater id and delete others.
			if ( count( $pageIds ) > 1 ) {
				foreach ( $pageIds as $page ) {
					if ( $page->ID > $pageId ) {
						if ( $pageId ) {
							$deleteIds[] = $pageId;
						}

						$pageId = $page->ID;
					} else {
						$deleteIds[] = $page->ID;
					}
				}
			} else {
				$pageId = $pageIds[0]->ID;
			}

			// Update `elementor_active_kit` page.
			if ( $pageId > 0 ) {
				wp_update_post(
					[
						'ID'        => $pageId,
						'post_name' => sanitize_title( 'Default Kit' ),
					]
				);
				update_option( 'elementor_active_kit', $pageId );
			}
		}

		return $this;
	}

	/**
	 * Sets the Elementor default settings.
	 *
	 * @return RTDemoimport
	 */
	private function set_elementor_settings() {
		update_option( 'elementor_disable_color_schemes', 'yes' );
		update_option( 'elementor_disable_typography_schemes', 'yes' );
		update_option( 'elementor_unfiltered_files_upload', '1' );
		update_option( 'elementor_experiment-e_font_icon_svg', 'inactive' );
		update_option( 'elementor_load_fa4_shim', 'yes' );
		update_option( 'elementor_experiment-e_swiper_latest', 'inactive' );

		return $this;
	}

	/**
	 * Updates the 'Hello World!' blog post by making it a draft
	 *
	 * @return RTDemoimport
	 */
	private function set_draft_post() {
		$helloWorld = $this->get_page_by_title( 'Hello World!', 'post' );

		if ( $helloWorld ) {
			$helloWorldArgs = [
				'ID'          => $helloWorld->ID,
				'post_status' => 'draft',
			];

			wp_update_post( $helloWorldArgs );
		}

		return $this;
	}

	/**
	 * Import fluent forms.
	 *
	 * @param array $selected_import Import array.
	 *
	 * @return void
	 */
	private function import_fluent_forms( $selected_import ) {
		if ( empty( $selected_import['local_import_file'] ) || ! is_plugin_active( 'fluentform/fluentform.php' ) ) {
			return;
		}

		$import_file = $selected_import['local_import_file'];
		$formFile    = trailingslashit( dirname( $import_file ) ) . 'fluentform.json';
		$fileExists  = file_exists( $formFile );

		if ( $fileExists ) {
			$data          = file_get_contents( $formFile );
			$forms         = json_decode( $data, true );
			$insertedForms = [];

			if ( $forms && is_array( $forms ) ) {
				foreach ( $forms as $formItem ) {
					$formFields = wp_json_encode( [] );
					if ( $fields = Arr::get( $formItem, 'form', '' ) ) {
						$formFields = wp_json_encode( $fields );
					} elseif ( $fields = Arr::get( $formItem, 'form_fields', '' ) ) {
						$formFields = wp_json_encode( $fields );
					}

					$form = [
						'title'       => Arr::get( $formItem, 'title' ),
						'form_fields' => $formFields,
						'status'      => Arr::get( $formItem, 'status', 'published' ),
						'has_payment' => Arr::get( $formItem, 'has_payment', 0 ),
						'type'        => Arr::get( $formItem, 'type', 'form' ),
						'created_by'  => get_current_user_id(),
					];

					if ( Arr::get( $formItem, 'conditions' ) ) {
						$form['conditions'] = Arr::get( $formItem, 'conditions' );
					}

					if ( isset( $formItem['appearance_settings'] ) ) {
						$form['appearance_settings'] = Arr::get( $formItem, 'appearance_settings' );
					}

					$formId                   = Form::insertGetId( $form );
					$insertedForms[ $formId ] = [
						'title'    => $form['title'],
						'edit_url' => admin_url( 'admin.php?page=fluent_forms&route=editor&form_id=' . $formId ),
					];

					if ( isset( $formItem['metas'] ) ) {
						foreach ( $formItem['metas'] as $metaData ) {
							$settings = [
								'form_id'  => $formId,
								'meta_key' => Arr::get( $metaData, 'meta_key' ),
								'value'    => Arr::get( $metaData, 'value' ),
							];

							FormMeta::insert( $settings );
						}
					} else {
						$oldKeys = [
							'formSettings',
							'notifications',
							'mailchimp_feeds',
							'slack',
						];

						foreach ( $oldKeys as $key ) {
							if ( isset( $formItem[ $key ] ) ) {
								FormMeta::persist( $formId, $key, wp_json_encode( Arr::get( $formItem, $key ) ) );
							}
						}
					}
				}
			}
		}
	}

	/**
	 * Install Demos Menu - Menu Edited
	 *
	 * @param array $default_settings Default settings.
	 * @return array
	 */
	public function import_page_setup( $default_settings ) {
		$default_settings['parent_slug'] = 'themes.php';
		$default_settings['page_title']  = esc_html__( 'Import Demo Data', 'neeon-core' );
		$default_settings['menu_title']  = esc_html__( 'Import Demo Data', 'neeon-core' );
		$default_settings['capability']  = 'import';
		$default_settings['menu_slug']   = 'install_demos';

		return $default_settings;
	}

	/**
	 * Generates and returns the introduction text for the RT Install Demos page.
	 *
	 * @param string $default_text The existing default text to append to.
	 *
	 * @return string
	 */
	public function intro_text( $default_text ) {
		$auto_install   = admin_url( 'themes.php?page=install_demos' );
		$manual_install = admin_url( 'themes.php?page=install_demos&import-mode=manual' );

		ob_start();
		?>
		<h1>RT Install Demos</h1>
		<div class="neeon-core_intro-text vtdemo-one-click">
			<div id="poststuff">
				<div class="postbox important-notes">
					<h3><span>Important notes:</span></h3>
					<div class="inside">
						<ol>
							<li>Please note, this import process will take time. So, please be patient.</li>
							<li>Please make sure you've installed recommended plugins before you import this content.</li>
							<li>All images are for demo purposes only. So, images may repeat in your site content.</li>
						</ol>
					</div>
				</div>

				<div class="postbox vt-support-box vt-error-box">
					<h3><span>Don't Edit Parent Theme Files:</span></h3>
					<div class="inside">
						<p>Don't edit any files from the parent theme! Use only <strong>Child Theme</strong> files for your customizations!</p>
						<p>If you receive future updates from our theme, you'll lose any edited customizations from your parent theme.</p>
					</div>
				</div>

				<div class="postbox vt-support-box">
					<h3><span>Need Support?</span> <a href="https://themeforest.net/user/rt" target="_blank" class="cs-section-video"><i class="fal fa-hand-point-right"></i> <span>How to?</span></a></h3>
					<div class="inside">
						<p>Have any doubts regarding this installation or any other issues? Please feel free to send us an email at rt@gmail.com.</p>
						<a href="https://themeforest.net/user/rt" class="button-primary" target="_blank">Docs</a>
						<a href="https://themeforest.net/user/rt/" class="button-primary" target="_blank">Support</a>
						<a href="https://themeforest.net/item/neeon/123456?ref=rt" class="button-primary" target="_blank">Item Page</a>
					</div>
				</div>
				<div class="nav-tab-wrapper vt-nav-tab">
					<?php
					// phpcs:ignore WordPress.Security.NonceVerification.Recommended
					$is_manual_mode      = isset( $_GET['import-mode'] ) && 'manual' === $_GET['import-mode'];
					$auto_active_class   = $is_manual_mode ? '' : ' nav-tab-active';
					$manual_active_class = $is_manual_mode ? ' nav-tab-active' : '';
					?>
					<a href="<?php echo esc_url( $auto_install ); ?>" class="nav-tab vt-mode-switch vt-auto-mode<?php echo esc_attr( $auto_active_class ); ?>">Auto Import</a>
					<a href="<?php echo esc_url( $manual_install ); ?>" class="nav-tab vt-mode-switch vt-manual-mode<?php echo esc_attr( $manual_active_class ); ?>">Manual Import</a>
				</div>
			</div>
		</div>
		<?php
		$default_text .= ob_get_clean();

		return $default_text;
	}


	/**
	 * Get page by title.
	 *
	 * @param string $title Page name.
	 * @param string $post_type Post type.
	 *
	 * @return WP_Post
	 */
	private function get_page_by_title( $title, $post_type = 'page' ) {
		$query = new WP_Query(
			[
				'post_type'              => esc_html( $post_type ),
				'title'                  => esc_html( $title ),
				'post_status'            => 'all',
				'posts_per_page'         => 1,
				'no_found_rows'          => true,
				'ignore_sticky_posts'    => true,
				'update_post_term_cache' => false,
				'update_post_meta_cache' => false,
				'orderby'                => 'post_date ID',
				'order'                  => 'ASC',
			],
		);

		return ! empty( $query->post ) ? $query->post : null;
	}

}

add_action( 'plugins_loaded', 'neeon_demo_importer_init' );
/**
 * Initializes the Redchili demo importer.
 *
 * @return RTDemoimport
 */
function neeon_demo_importer_init() {
	return new RTDemoimport();
}
