<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

namespace radiustheme\Neeon_Core;
use \RT_Posts;
use NeeonTheme;


if ( !class_exists( 'RT_Posts' ) ) {
	return;
}

$post_types = array(
	'neeon_team'       => array(
		'title'           => __( 'Team Member', 'neeon-core' ),
		'plural_title'    => __( 'Team', 'neeon-core' ),
		'menu_icon'       => 'dashicons-businessman',
		'labels_override' => array(
			'menu_name'   => __( 'Team', 'neeon-core' ),
		),
		'rewrite'         => NeeonTheme::$options['team_slug'],
		'supports'        => array( 'title', 'thumbnail', 'editor', 'excerpt', 'page-attributes' )
	),
);

$taxonomies = array(
	'neeon_team_category' => array(
		'title'        => __( 'Team Category', 'neeon-core' ),
		'plural_title' => __( 'Team Categories', 'neeon-core' ),
		'post_types'   => 'neeon_team',
		'rewrite'      => array( 'slug' => NeeonTheme::$options['team_cat_slug'] ),
	),
);

$Posts = RT_Posts::getInstance();
$Posts->add_post_types( $post_types );
$Posts->add_taxonomies( $taxonomies );