<?php
/**
 * @author  RadiusTheme
 * @since   1.0
 * @version 1.0
 */

?>
<div class="search-icon">
	<a href="#header-search" title="<?php esc_attr_e( 'Search', 'neeon');?>">
	    <?php echo radius_search_shape(); ?>
	</a>
</div>

