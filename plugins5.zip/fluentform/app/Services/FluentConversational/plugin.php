<?php

defined('ABSPATH') or die;

define('FLUENT_CONVERSATIONAL_FORM', true);
define('FLUENT_CONVERSATIONAL_FORM_VERSION', '1.0.0');
define('FLUENT_CONVERSATIONAL_FORM_DIR_URL', plugin_dir_url(__FILE__));
define('FLUENT_CONVERSATIONAL_FORM_DIR_PATH', plugin_dir_path(__FILE__));
